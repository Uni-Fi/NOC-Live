var __wsconf = window.__wsconf = window.__wsconf || {};
__wsconf.section = '1342';
__wsconf.appId = '1788';
__wsconf.znl = {};
__wsconf.rootPath = '//webservices.webspectator.com';
__wsconf.sessionId = '28307CD6A32DCBB9';
__wsconf.contextId = '6924';
__wsconf.cid = '33A24448';
__wsconf.vtm = 'TFPC';
__wsconf.g_country = 'US';
__wsconf.g_region = 'CT';
__wsconf.g_city = '4839822';
__wsconf.dads = 0;
__wsconf.dfm = 1;
__wsconf.lts = 0;
__wsconf.adBlckMsg = false;
__wsconf.adBlckMsgTxt = '';
__wsconf.frt= "30";
__wsconf.mui= "99";
__wsconf.ortc= {"url":"window.location.protocol + \u0027//msgws.webspectator.com/server\u0027 + (window.location.protocol \u003d\u003d \u0027https:\u0027 ? \u0027/ssl/\u0027 : \u0027/\u0027) + \u00272.1/\u0027","apk":"w5tlOg","aut":"ws.client"};
__wsconf.smc= {"idleTimer":15.0,"disconnectTimer":120.0};


var s0 = document.createElement('script');
s0.type = 'text/javascript';
s0.async = true;
s0.src = (window.location.protocol == "https:" ? "https:" : "http:")+"//wfpscripts.webspectator.com/ortc-heartbeat1sec-min.js";
document.getElementsByTagName('HEAD')[0].appendChild(s0);

var s1 = document.createElement('script');
s1.type = 'text/javascript';
s1.async = true;
s1.src = (window.location.protocol == "https:" ? "https:" : "http:")+"//ajax.googleapis.com/ajax/libs/swfobject/2.2/swfobject.js";
document.getElementsByTagName('HEAD')[0].appendChild(s1);

var s2 = document.createElement('script');
s2.type = 'text/javascript';
s2.async = true;
s2.src = (window.location.protocol == "https:" ? "https:" : "http:")+"//wfpscripts.webspectator.com/adblocker/blockadblock.js";
document.getElementsByTagName('HEAD')[0].appendChild(s2);

var s3 = document.createElement('script');
s3.type = 'text/javascript';
s3.async = true;
s3.src = (window.location.protocol == "https:" ? "https:" : "http:")+"//wfpscripts.webspectator.com/ws-4.4.62.js";
document.getElementsByTagName('HEAD')[0].appendChild(s3);

