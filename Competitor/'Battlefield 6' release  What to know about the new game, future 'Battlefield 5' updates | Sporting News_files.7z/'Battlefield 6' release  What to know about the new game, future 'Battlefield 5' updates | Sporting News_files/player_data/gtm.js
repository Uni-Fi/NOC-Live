
// Copyright 2012 Google Inc. All rights reserved.
(function(){

var data = {
"resource": {
  "version":"154",
  
  "macros":[{
      "function":"__e"
    },{
      "function":"__e"
    },{
      "function":"__v",
      "vtp_name":"ePlayer_Channel",
      "vtp_dataLayerVersion":2
    },{
      "function":"__v",
      "vtp_name":"ePlayer_Content_Type",
      "vtp_dataLayerVersion":2
    },{
      "function":"__v",
      "vtp_name":"ePlayer_Partner_ID",
      "vtp_dataLayerVersion":2
    },{
      "function":"__v",
      "vtp_name":"ePlayer_Play_Configuration",
      "vtp_dataLayerVersion":2
    },{
      "function":"__v",
      "vtp_name":"ePlayer_Region",
      "vtp_dataLayerVersion":2
    },{
      "function":"__v",
      "vtp_name":"ePlayer_URL",
      "vtp_dataLayerVersion":2
    },{
      "function":"__v",
      "vtp_name":"ePlayer_Video",
      "vtp_dataLayerVersion":2
    },{
      "function":"__v",
      "vtp_name":"ePlayer_Sound",
      "vtp_dataLayerVersion":2
    },{
      "function":"__v",
      "vtp_name":"ePlayer_Size",
      "vtp_dataLayerVersion":2
    },{
      "function":"__v",
      "vtp_name":"ePlayer_Player_ID",
      "vtp_dataLayerVersion":2
    },{
      "function":"__v",
      "vtp_name":"ePlayer_Video_ID",
      "vtp_dataLayerVersion":2
    },{
      "function":"__v",
      "vtp_name":"ePlayer_Channel_ID",
      "vtp_dataLayerVersion":2
    },{
      "function":"__v",
      "vtp_name":"ePlayer_Version",
      "vtp_dataLayerVersion":2
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"ePlayer_RightsHolder"
    },{
      "function":"__v",
      "vtp_name":"ePlayer_Clip_Length",
      "vtp_dataLayerVersion":2
    },{
      "function":"__v",
      "vtp_name":"ePlayer_Playlist_ID",
      "vtp_dataLayerVersion":2
    },{
      "function":"__v",
      "vtp_name":"ePlayer_Genre",
      "vtp_dataLayerVersion":2
    },{
      "function":"__v",
      "vtp_name":"ePlayer_Category",
      "vtp_dataLayerVersion":2
    },{
      "function":"__v",
      "vtp_name":"eplayer-video-end",
      "vtp_dataLayerVersion":2
    },{
      "function":"__v",
      "vtp_name":"ePlayer_Player_Type",
      "vtp_dataLayerVersion":2
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"ePlayer_Delivery"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"ePlayer_Size_Grouped"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"ePlayer_Build_Version"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"GDPR_Applies"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"GDPR_Perform_Consent"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"GDPR_Vendor_Consent"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"performId"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"performIdAnsii"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"ePlayer_Domain"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"ePlayer_Loaded_Source"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"Player_Embed_Code"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"ePlayer_Ad_Blocked"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"Player_PageKeywords"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"Player_Pods"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"",
      "vtp_name":"Player_AdPosition"
    },{
      "function":"__e"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"ePlayer_Rights"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"BlueKai_Primary_Tag"
    },{
      "function":"__r"
    },{
      "function":"__r"
    },{
      "function":"__u",
      "vtp_component":"URL",
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__u",
      "vtp_component":"HOST",
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__u",
      "vtp_component":"PATH",
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__f"
    },{
      "function":"__aev",
      "vtp_varType":"CLASSES"
    },{
      "function":"__aev",
      "vtp_varType":"ID"
    },{
      "function":"__aev",
      "vtp_varType":"TARGET"
    },{
      "function":"__aev",
      "vtp_varType":"TEXT"
    },{
      "function":"__aev",
      "vtp_varType":"URL"
    },{
      "function":"__aev",
      "vtp_varType":"HISTORY_NEW_URL_FRAGMENT"
    },{
      "function":"__aev",
      "vtp_varType":"HISTORY_OLD_URL_FRAGMENT"
    },{
      "function":"__aev",
      "vtp_varType":"HISTORY_NEW_STATE"
    },{
      "function":"__aev",
      "vtp_varType":"HISTORY_OLD_STATE"
    },{
      "function":"__aev",
      "vtp_varType":"HISTORY_CHANGE_SOURCE"
    },{
      "function":"__e"
    }],
  "tags":[{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_useDebugVersion":false,
      "vtp_useHashAutoLink":false,
      "vtp_trackType":"TRACK_PAGEVIEW",
      "vtp_decorateFormsAutoLink":false,
      "vtp_overrideGaSettings":true,
      "vtp_setTrackerName":false,
      "vtp_doubleClick":false,
      "vtp_fieldsToSet":["list",["map","fieldName","cookieDomain","value","player.performgroup.com"]],
      "vtp_metric":["list",["map","index","2","metric","1"]],
      "vtp_enableLinkId":false,
      "vtp_dimension":["list",["map","index","1","dimension",["macro",2]],["map","index","2","dimension",["macro",3]],["map","index","3","dimension",["macro",4]],["map","index","4","dimension",["macro",5]],["map","index","5","dimension",["macro",6]],["map","index","6","dimension",["macro",7]],["map","index","7","dimension",["macro",8]],["map","index","8","dimension",["macro",9]],["map","index","9","dimension",["macro",10]],["map","index","10","dimension",["macro",11]],["map","index","11","dimension",["macro",12]],["map","index","12","dimension",["macro",13]],["map","index","13","dimension",["macro",14]],["map","index","14","dimension",["macro",15]],["map","index","15","dimension",["macro",16]],["map","index","16","dimension",["macro",17]],["map","index","17","dimension",["macro",18]],["map","index","18","dimension",["macro",19]],["map","index","19","dimension",["macro",20]],["map","index","20","dimension",["macro",21]],["map","index","21","dimension",["macro",22]],["map","index","23","dimension",["macro",23]],["map","index","24","dimension",["macro",24]],["map","index","25","dimension",["macro",25]],["map","index","26","dimension",["macro",26]],["map","index","27","dimension",["macro",27]],["map","index","29","dimension",["macro",28]],["map","index","30","dimension",["macro",29]],["map","index","28","dimension",["macro",30]],["map","index","32","dimension",["macro",31]],["map","index","40","dimension",["macro",32]]],
      "vtp_enableEcommerce":false,
      "vtp_trackingId":"UA-60606653-1",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "tag_id":6
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":true,
      "vtp_doubleClick":false,
      "vtp_setTrackerName":false,
      "vtp_useDebugVersion":false,
      "vtp_fieldsToSet":["list",["map","fieldName","anonymizeIp","value","false"]],
      "vtp_trackType":"TRACK_EVENT",
      "vtp_metric":["list",["map","index","1","metric","1"]],
      "vtp_enableLinkId":false,
      "vtp_dimension":["list",["map","index","1","dimension",["macro",2]],["map","index","2","dimension",["macro",3]],["map","index","3","dimension",["macro",4]],["map","index","4","dimension",["macro",5]],["map","index","5","dimension",["macro",6]],["map","index","6","dimension",["macro",7]],["map","index","7","dimension",["macro",8]],["map","index","8","dimension",["macro",9]],["map","index","9","dimension",["macro",10]],["map","index","10","dimension",["macro",11]],["map","index","11","dimension",["macro",12]],["map","index","12","dimension",["macro",13]],["map","index","13","dimension",["macro",14]],["map","index","14","dimension",["macro",15]],["map","index","15","dimension",["macro",16]],["map","index","16","dimension",["macro",17]],["map","index","17","dimension",["macro",18]],["map","index","18","dimension",["macro",19]],["map","index","19","dimension",["macro",20]],["map","index","20","dimension",["macro",21]],["map","index","21","dimension",["macro",22]],["map","index","22","dimension",["macro",33]],["map","index","23","dimension",["macro",23]],["map","index","24","dimension",["macro",24]],["map","index","32","dimension",["macro",31]],["map","index","28","dimension",["macro",30]],["map","index","36","dimension",["macro",34]],["map","index","38","dimension",["macro",35]],["map","index","39","dimension",["macro",36]],["map","index","40","dimension",["macro",32]]],
      "vtp_enableEcommerce":false,
      "vtp_trackingId":"UA-60606653-1",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":25
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":true,
      "vtp_doubleClick":false,
      "vtp_setTrackerName":false,
      "vtp_useDebugVersion":false,
      "vtp_fieldsToSet":["list",["map","fieldName","anonymizeIp","value","false"]],
      "vtp_trackType":"TRACK_EVENT",
      "vtp_metric":["list",["map","index","3","metric","1"]],
      "vtp_enableLinkId":false,
      "vtp_dimension":["list",["map","index","1","dimension",["macro",2]],["map","index","2","dimension",["macro",3]],["map","index","3","dimension",["macro",4]],["map","index","4","dimension",["macro",5]],["map","index","5","dimension",["macro",6]],["map","index","6","dimension",["macro",7]],["map","index","7","dimension",["macro",8]],["map","index","8","dimension",["macro",9]],["map","index","9","dimension",["macro",10]],["map","index","10","dimension",["macro",11]],["map","index","11","dimension",["macro",12]],["map","index","12","dimension",["macro",13]],["map","index","13","dimension",["macro",14]],["map","index","14","dimension",["macro",15]],["map","index","15","dimension",["macro",16]],["map","index","16","dimension",["macro",17]],["map","index","17","dimension",["macro",18]],["map","index","18","dimension",["macro",19]],["map","index","19","dimension",["macro",20]],["map","index","20","dimension",["macro",21]],["map","index","21","dimension",["macro",22]],["map","index","23","dimension",["macro",23]],["map","index","24","dimension",["macro",24]],["map","index","32","dimension",["macro",31]],["map","index","28","dimension",["macro",30]],["map","index","38","dimension",["macro",35]],["map","index","39","dimension",["macro",36]],["map","index","40","dimension",["macro",32]]],
      "vtp_enableEcommerce":false,
      "vtp_trackingId":"UA-60606653-1",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":26
    },{
      "function":"__paused",
      "vtp_originalTagType":"ua",
      "tag_id":28
    },{
      "function":"__paused",
      "vtp_originalTagType":"ua",
      "tag_id":29
    },{
      "function":"__ua",
      "live_only":true,
      "once_per_event":true,
      "vtp_trackingId":"UA-60606653-1",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_nonInteraction":false,
      "vtp_useDebugVersion":false,
      "vtp_enableLinkId":false,
      "vtp_doubleClick":false,
      "vtp_advertisingFeaturesType":"NONE",
      "vtp_eventCategory":["macro",37],
      "vtp_eventAction":["macro",37],
      "vtp_eventLabel":["macro",2],
      "vtp_enableEcommerce":false,
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":35
    },{
      "function":"__ua",
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":true,
      "vtp_doubleClick":false,
      "vtp_useDebugVersion":false,
      "vtp_fieldsToSet":["list",["map","fieldName","anonymizeIp","value","false"]],
      "vtp_trackType":"TRACK_EVENT",
      "vtp_metric":["list",["map","index","6","metric","1"]],
      "vtp_enableLinkId":false,
      "vtp_dimension":["list",["map","index","1","dimension",["macro",2]],["map","index","2","dimension",["macro",3]],["map","index","3","dimension",["macro",4]],["map","index","4","dimension",["macro",5]],["map","index","5","dimension",["macro",6]],["map","index","6","dimension",["macro",7]],["map","index","7","dimension",["macro",8]],["map","index","8","dimension",["macro",9]],["map","index","9","dimension",["macro",10]],["map","index","10","dimension",["macro",11]],["map","index","11","dimension",["macro",12]],["map","index","12","dimension",["macro",13]],["map","index","13","dimension",["macro",14]],["map","index","14","dimension",["macro",38]],["map","index","15","dimension",["macro",16]],["map","index","16","dimension",["macro",17]],["map","index","17","dimension",["macro",18]],["map","index","18","dimension",["macro",19]],["map","index","19","dimension",["macro",20]],["map","index","20","dimension",["macro",21]],["map","index","24","dimension",["macro",24]]],
      "vtp_enableEcommerce":false,
      "vtp_trackingId":"UA-60606653-1",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":36
    },{
      "function":"__paused",
      "vtp_originalTagType":"ua",
      "tag_id":45
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":true,
      "vtp_doubleClick":false,
      "vtp_setTrackerName":false,
      "vtp_useDebugVersion":false,
      "vtp_fieldsToSet":["list",["map","fieldName","anonymizeIp","value","false"]],
      "vtp_trackType":"TRACK_EVENT",
      "vtp_metric":["list",["map","index","7","metric","1"]],
      "vtp_enableLinkId":false,
      "vtp_dimension":["list",["map","index","1","dimension",["macro",2]],["map","index","2","dimension",["macro",3]],["map","index","3","dimension",["macro",4]],["map","index","4","dimension",["macro",5]],["map","index","5","dimension",["macro",6]],["map","index","6","dimension",["macro",7]],["map","index","7","dimension",["macro",8]],["map","index","8","dimension",["macro",9]],["map","index","9","dimension",["macro",10]],["map","index","10","dimension",["macro",11]],["map","index","11","dimension",["macro",12]],["map","index","12","dimension",["macro",13]],["map","index","13","dimension",["macro",14]],["map","index","14","dimension",["macro",38]],["map","index","15","dimension",["macro",16]],["map","index","16","dimension",["macro",17]],["map","index","17","dimension",["macro",18]],["map","index","18","dimension",["macro",19]],["map","index","19","dimension",["macro",20]],["map","index","20","dimension",["macro",21]],["map","index","24","dimension",["macro",24]],["map","index","32","dimension",["macro",31]],["map","index","28","dimension",["macro",30]]],
      "vtp_enableEcommerce":false,
      "vtp_trackingId":"UA-60606653-1",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":46
    },{
      "function":"__ua",
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":true,
      "vtp_doubleClick":false,
      "vtp_setTrackerName":false,
      "vtp_useDebugVersion":false,
      "vtp_fieldsToSet":["list",["map","fieldName","anonymizeIp","value","false"]],
      "vtp_trackType":"TRACK_EVENT",
      "vtp_metric":["list",["map","index","8","metric","1"]],
      "vtp_enableLinkId":false,
      "vtp_dimension":["list",["map","index","1","dimension",["macro",2]],["map","index","2","dimension",["macro",3]],["map","index","3","dimension",["macro",4]],["map","index","4","dimension",["macro",5]],["map","index","5","dimension",["macro",6]],["map","index","6","dimension",["macro",7]],["map","index","7","dimension",["macro",8]],["map","index","8","dimension",["macro",9]],["map","index","9","dimension",["macro",10]],["map","index","10","dimension",["macro",11]],["map","index","11","dimension",["macro",12]],["map","index","12","dimension",["macro",13]],["map","index","13","dimension",["macro",14]],["map","index","14","dimension",["macro",38]],["map","index","15","dimension",["macro",16]],["map","index","16","dimension",["macro",17]],["map","index","17","dimension",["macro",18]],["map","index","18","dimension",["macro",19]],["map","index","19","dimension",["macro",20]],["map","index","20","dimension",["macro",21]],["map","index","24","dimension",["macro",24]],["map","index","32","dimension",["macro",31]],["map","index","28","dimension",["macro",30]]],
      "vtp_enableEcommerce":false,
      "vtp_trackingId":"UA-60606653-1",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":47
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":49
    },{
      "function":"__paused",
      "vtp_originalTagType":"ua",
      "tag_id":51
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":true,
      "vtp_doubleClick":false,
      "vtp_setTrackerName":false,
      "vtp_useDebugVersion":false,
      "vtp_fieldsToSet":["list",["map","fieldName","anonymizeIp","value","false"]],
      "vtp_trackType":"TRACK_EVENT",
      "vtp_metric":["list",["map","index","10","metric","1"]],
      "vtp_enableLinkId":false,
      "vtp_dimension":["list",["map","index","1","dimension",["macro",2]],["map","index","2","dimension",["macro",3]],["map","index","3","dimension",["macro",4]],["map","index","4","dimension",["macro",5]],["map","index","5","dimension",["macro",6]],["map","index","6","dimension",["macro",7]],["map","index","7","dimension",["macro",8]],["map","index","8","dimension",["macro",9]],["map","index","9","dimension",["macro",10]],["map","index","10","dimension",["macro",11]],["map","index","11","dimension",["macro",12]],["map","index","12","dimension",["macro",13]],["map","index","13","dimension",["macro",14]],["map","index","14","dimension",["macro",15]],["map","index","15","dimension",["macro",16]],["map","index","16","dimension",["macro",17]],["map","index","17","dimension",["macro",18]],["map","index","18","dimension",["macro",19]],["map","index","19","dimension",["macro",20]],["map","index","20","dimension",["macro",21]],["map","index","21","dimension",["macro",22]],["map","index","22","dimension",["macro",33]],["map","index","23","dimension",["macro",23]],["map","index","24","dimension",["macro",24]],["map","index","32","dimension",["macro",31]],["map","index","28","dimension",["macro",30]]],
      "vtp_enableEcommerce":false,
      "vtp_trackingId":"UA-60606653-1",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":63
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":64
    },{
      "function":"__ua",
      "unlimited":true,
      "vtp_nonInteraction":false,
      "vtp_useDebugVersion":false,
      "vtp_eventCategory":"Video View",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_eventAction":["macro",8],
      "vtp_eventLabel":["macro",2],
      "vtp_overrideGaSettings":true,
      "vtp_doubleClick":false,
      "vtp_setTrackerName":false,
      "vtp_fieldsToSet":["list",["map","fieldName","anonymizeIp","value","false"],["map","fieldName","title","value",["macro",8]],["map","fieldName","page","value",["macro",4]]],
      "vtp_eventValue":"1",
      "vtp_metric":["list",["map","index","1","metric","1"]],
      "vtp_enableLinkId":false,
      "vtp_dimension":["list",["map","index","1","dimension",["macro",2]],["map","index","2","dimension",["macro",3]],["map","index","3","dimension",["macro",4]],["map","index","4","dimension",["macro",5]],["map","index","5","dimension",["macro",6]],["map","index","6","dimension",["macro",7]],["map","index","7","dimension",["macro",8]],["map","index","8","dimension",["macro",9]],["map","index","9","dimension",["macro",10]],["map","index","10","dimension",["macro",11]],["map","index","11","dimension",["macro",12]],["map","index","12","dimension",["macro",13]],["map","index","13","dimension",["macro",14]],["map","index","14","dimension",["macro",15]],["map","index","15","dimension",["macro",16]],["map","index","16","dimension",["macro",17]],["map","index","17","dimension",["macro",18]],["map","index","18","dimension",["macro",19]],["map","index","19","dimension",["macro",20]],["map","index","20","dimension",["macro",21]],["map","index","24","dimension",["macro",24]]],
      "vtp_enableEcommerce":false,
      "vtp_trackingId":"UA-60606653-4",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":73
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":77
    },{
      "function":"__paused",
      "vtp_originalTagType":"html",
      "tag_id":78
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":true,
      "vtp_doubleClick":false,
      "vtp_setTrackerName":false,
      "vtp_useDebugVersion":false,
      "vtp_fieldsToSet":["list",["map","fieldName","anonymizeIp","value","false"]],
      "vtp_trackType":"TRACK_EVENT",
      "vtp_metric":["list",["map","index","14","metric","1"]],
      "vtp_enableLinkId":false,
      "vtp_dimension":["list",["map","index","6","dimension",["macro",7]],["map","index","3","dimension",["macro",4]],["map","index","4","dimension",["macro",5]],["map","index","5","dimension",["macro",6]],["map","index","1","dimension",["macro",2]],["map","index","2","dimension",["macro",3]],["map","index","7","dimension",["macro",8]],["map","index","8","dimension",["macro",9]],["map","index","9","dimension",["macro",10]],["map","index","10","dimension",["macro",11]],["map","index","11","dimension",["macro",12]],["map","index","12","dimension",["macro",13]],["map","index","13","dimension",["macro",14]],["map","index","15","dimension",["macro",16]],["map","index","16","dimension",["macro",17]],["map","index","17","dimension",["macro",18]],["map","index","18","dimension",["macro",19]],["map","index","19","dimension",["macro",20]],["map","index","20","dimension",["macro",21]],["map","index","22","dimension",["macro",33]],["map","index","21","dimension",["macro",22]],["map","index","14","dimension",["macro",15]],["map","index","23","dimension",["macro",23]],["map","index","33","dimension",["macro",39]],["map","index","24","dimension",["macro",24]],["map","index","28","dimension",["macro",30]],["map","index","25","dimension",["macro",25]],["map","index","26","dimension",["macro",26]],["map","index","27","dimension",["macro",27]],["map","index","29","dimension",["macro",28]],["map","index","30","dimension",["macro",29]],["map","index","32","dimension",["macro",31]],["map","index","40","dimension",["macro",32]]],
      "vtp_enableEcommerce":false,
      "vtp_trackingId":"UA-60606653-1",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":80
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_overrideGaSettings":true,
      "vtp_doubleClick":false,
      "vtp_setTrackerName":false,
      "vtp_useDebugVersion":false,
      "vtp_useHashAutoLink":false,
      "vtp_trackType":"TRACK_PAGEVIEW",
      "vtp_metric":["list",["map","index","15","metric","1"]],
      "vtp_decorateFormsAutoLink":false,
      "vtp_enableLinkId":false,
      "vtp_dimension":["list",["map","index","6","dimension",["macro",7]],["map","index","3","dimension",["macro",4]],["map","index","4","dimension",["macro",5]],["map","index","5","dimension",["macro",6]],["map","index","1","dimension",["macro",2]],["map","index","2","dimension",["macro",3]],["map","index","7","dimension",["macro",8]],["map","index","8","dimension",["macro",9]],["map","index","9","dimension",["macro",10]],["map","index","10","dimension",["macro",11]],["map","index","11","dimension",["macro",12]],["map","index","12","dimension",["macro",13]],["map","index","13","dimension",["macro",14]],["map","index","15","dimension",["macro",16]],["map","index","16","dimension",["macro",17]],["map","index","17","dimension",["macro",18]],["map","index","18","dimension",["macro",19]],["map","index","19","dimension",["macro",20]],["map","index","20","dimension",["macro",21]],["map","index","22","dimension",["macro",33]],["map","index","21","dimension",["macro",22]],["map","index","14","dimension",["macro",15]],["map","index","23","dimension",["macro",23]],["map","index","24","dimension",["macro",24]],["map","index","28","dimension",["macro",30]],["map","index","25","dimension",["macro",25]],["map","index","26","dimension",["macro",26]],["map","index","27","dimension",["macro",27]],["map","index","29","dimension",["macro",28]],["map","index","30","dimension",["macro",29]],["map","index","32","dimension",["macro",31]],["map","index","40","dimension",["macro",32]]],
      "vtp_enableEcommerce":false,
      "vtp_trackingId":"UA-60606653-1",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "tag_id":81
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_useDebugVersion":false,
      "vtp_useHashAutoLink":false,
      "vtp_trackType":"TRACK_PAGEVIEW",
      "vtp_decorateFormsAutoLink":false,
      "vtp_overrideGaSettings":true,
      "vtp_doubleClick":false,
      "vtp_setTrackerName":false,
      "vtp_fieldsToSet":["list",["map","fieldName","cookieDomain","value","player.performgroup.com"]],
      "vtp_metric":["list",["map","index","16","metric","1"]],
      "vtp_enableLinkId":false,
      "vtp_dimension":["list",["map","index","28","dimension",["macro",30]],["map","index","6","dimension",["macro",7]]],
      "vtp_enableEcommerce":false,
      "vtp_trackingId":"UA-60606653-1",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "tag_id":83
    },{
      "function":"__img",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_useCacheBuster":true,
      "vtp_url":"https:\/\/atm.im-apps.net\/a\/beacon.gif?cid=1001545\u0026c1=201906\u0026c2=dazn\u0026c3=adesense\u0026c4=goal",
      "vtp_cacheBusterQueryParam":"gtmcb",
      "vtp_randomNumber":["macro",40],
      "tag_id":84
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_overrideGaSettings":true,
      "vtp_doubleClick":false,
      "vtp_setTrackerName":false,
      "vtp_useDebugVersion":false,
      "vtp_fieldsToSet":["list",["map","fieldName","anonymizeIp","value","false"]],
      "vtp_trackType":"TRACK_PAGEVIEW",
      "vtp_metric":["list",["map","index","17","metric","1"]],
      "vtp_enableLinkId":false,
      "vtp_dimension":["list",["map","index","24","dimension",["macro",24]],["map","index","1","dimension",["macro",2]],["map","index","12","dimension",["macro",13]],["map","index","21","dimension",["macro",22]],["map","index","28","dimension",["macro",30]],["map","index","32","dimension",["macro",31]],["map","index","3","dimension",["macro",4]],["map","index","4","dimension",["macro",5]],["map","index","20","dimension",["macro",21]],["map","index","5","dimension",["macro",6]],["map","index","9","dimension",["macro",10]],["map","index","6","dimension",["macro",7]],["map","index","7","dimension",["macro",8]],["map","index","39","dimension",["macro",36]],["map","index","38","dimension",["macro",35]],["map","index","8","dimension",["macro",9]],["map","index","11","dimension",["macro",12]]],
      "vtp_enableEcommerce":false,
      "vtp_trackingId":"UA-60606653-1",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "tag_id":85
    },{
      "function":"__html",
      "vtp_html":" \n\u003Cscript\u003Edocument.write(unescape(\"%3Cscript src\\x3d'\"+(\"https:\"==document.location.protocol?\"https:\/\/sb\":\"http:\/\/b\")+\".scorecardresearch.com\/beacon.js' %3E%3C\/script%3E\"));\u003C\/script\u003E \n\u003Cscript\u003ECOMSCORE.beacon({c1:1,c2:\"6035584\",c3:\"6035584\",c4:\"9266697\",c5:\"000000\",c6:\"\",c10:\"\"});\u003C\/script\u003E \n\u003Cnoscript\u003E \n\u003Cimg src=\"http:\/\/b.scorecardresearch.com\/p?c1=1\u0026amp;c2=\u0026amp;c3=\u0026amp;c4=\u0026amp;c5=\u0026amp;c6=\u0026amp;c10=\u0026amp;cv=2.0\u0026amp;cj=1\"\u003E \n\u003C\/noscript\u003E \n",
      "vtp_convertJsValuesToExpressions":true,
      "vtp_supportDocumentWrite":true,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "vtp_usePostscribe":true,
      "tag_id":5
    },{
      "function":"__html",
      "vtp_html":" \n\u003Cscript\u003Edocument.write(unescape(\"%3Cscript src\\x3d'\"+(\"https:\"==document.location.protocol?\"https:\/\/sb\":\"http:\/\/b\")+\".scorecardresearch.com\/beacon.js' %3E%3C\/script%3E\"));\u003C\/script\u003E \n\u003Cscript\u003ECOMSCORE.beacon({c1:1,c2:\"6035584\",c3:\"6035584\",c4:\"9266697\",c5:\"000000\",c6:\"sportingnews\",c10:\"\"});\u003C\/script\u003E \n\u003Cnoscript\u003E \n\u003Cimg src=\"http:\/\/b.scorecardresearch.com\/p?c1=1\u0026amp;c2=\u0026amp;c3=\u0026amp;c4=\u0026amp;c5=\u0026amp;c6=\u0026amp;c10=\u0026amp;cv=2.0\u0026amp;cj=1\"\u003E \n\u003C\/noscript\u003E \n",
      "vtp_convertJsValuesToExpressions":true,
      "vtp_supportDocumentWrite":true,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "vtp_usePostscribe":true,
      "tag_id":31
    },{
      "function":"__html",
      "once_per_event":true,
      "vtp_html":"\n\u003Cscript type=\"text\/javascript\" src=\"https:\/\/script.ioam.de\/iam.js\"\u003E\u003C\/script\u003E\n\u003Cscript type=\"text\/javascript\"\u003Evar iam_data={st:\"goalcom\",cp:\"goal_online_fuss_Deu_video_red_0_online_0_free_82Sport_instream\",sv:\"ke\",co:\"\"};iom.c(iam_data,1);\u003C\/script\u003E",
      "vtp_supportDocumentWrite":true,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "vtp_usePostscribe":true,
      "tag_id":44
    },{
      "function":"__html",
      "once_per_event":true,
      "vtp_html":"\u003Cscript language=\"JavaScript\" type=\"text\/gtmscript\"\u003E(function(){var a=document.createElement(\"script\");a.type=\"text\/javascript\";a.async=!0;var b=encodeURIComponent(\"http:\/\/www.effectivemeasure.com\/test-video\");a.src=\"https:\/\/s.effectivemeasure.net\/video\/js\/video.min.js?page_url\\x3d\"+b;b=document.getElementsByTagName(\"script\")[0];b.parentNode.insertBefore(a,b)})();\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":50
    },{
      "function":"__html",
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003E(function(a,d,c,b){a=\"\/\/tags.tiqcdn.com\/utag\/axelspringer\/bild\/prod\/utag.js\";d=document;c=\"script\";b=d.createElement(c);b.src=a;b.type=\"text\/java\"+c;b.async=!0;a=d.getElementsByTagName(c)[0];a.parentNode.insertBefore(b,a)})();\u003C\/script\u003E\n\u003Cscript type=\"text\/gtmscript\"\u003Eutag.track(\"media-eplayer\",{page_name:\"sport\/artikel\/fussball\/international\/2016\/08\/15\/klopp-show-im-video\/diese-england-videos-muessen-sie-sehen\",page_id:\"7f5bdbae1bcd3c86ad3a5b9274\",eventName:\"init\",headline:\" Guardiola: Bravo Tut mir Leid,Leute\"});\u003C\/script\u003E\n",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":52
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":["template"," \n\u003Cscript type=\"text\/gtmscript\"\u003Ewindow.bk_async=function(){bk_addPageCtx(\"Player_Load\",\"Player_Load\");bk_addPageCtx(\"ePlayer_Channel_Name\",\"",["escape",["macro",2],7],"\");bk_addPageCtx(\"ePlayer_Partner_ID\",\"",["escape",["macro",4],7],"\");bk_addPageCtx(\"BlueKai_Primary_Tag\",\"",["escape",["macro",39],7],"\");BKTAG.doTag(53602,1)};(function(){var b=document.getElementsByTagName(\"script\")[0],a=document.createElement(\"script\");a.async=!0;a.src=\"https:\/\/tags.bkrtx.com\/js\/bk-coretag.js\";b.parentNode.insertBefore(a,b)})();\u003C\/script\u003E \n "],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":68
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":["template"," \n\u003Cscript type=\"text\/gtmscript\"\u003Ewindow.bk_async=function(){bk_addPageCtx(\"Content_View\",\"Content_View\");bk_addPageCtx(\"ePlayer_Channel_Name\",\"",["escape",["macro",2],7],"\");bk_addPageCtx(\"ePlayer_Partner_ID\",\"",["escape",["macro",4],7],"\");bk_addPageCtx(\"Play_Configuration\",\"",["escape",["macro",5],7],"\");bk_addPageCtx(\"ePlayer_RightsHolder\",\"",["escape",["macro",15],7],"\");bk_addPageCtx(\"Player_PageKeywords\",\"",["escape",["macro",34],7],"\");BKTAG.doTag(53602,1)};\n(function(){var b=document.getElementsByTagName(\"script\")[0],a=document.createElement(\"script\");a.async=!0;a.src=\"https:\/\/tags.bkrtx.com\/js\/bk-coretag.js\";b.parentNode.insertBefore(a,b)})();\u003C\/script\u003E \n "],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":69
    },{
      "function":"__html",
      "once_per_load":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003E_tfa.push({notify:\"event\",name:\"VideoView\"});\u003C\/script\u003E\n\u003Cnoscript\u003E\n\t\u003Cimg src=\"\/\/trc.taboola.com\/1149108\/log\/3\/unip?en=VideoView\" width=\"0\" height=\"0\" style=\"display:none\"\u003E\n\u003C\/noscript\u003E\n",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":71
    },{
      "function":"__html",
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Ewindow._tfa=window._tfa||[];window._tfa.push({notify:\"event\",name:\"page_view\"});!function(a,b,d,c){document.getElementById(c)||(a.async=1,a.src=d,a.id=c,b.parentNode.insertBefore(a,b))}(document.createElement(\"script\"),document.getElementsByTagName(\"script\")[0],\"\/\/cdn.taboola.com\/libtrc\/unip\/1149108\/tfa.js\",\"tb_tfa_script\");\u003C\/script\u003E\n\u003Cnoscript\u003E\n  \u003Cimg src=\"\/\/trc.taboola.com\/1149108\/log\/3\/unip?en=page_view\" width=\"0\" height=\"0\" style=\"display:none\"\u003E\n\u003C\/noscript\u003E\n",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":72
    },{
      "function":"__html",
      "once_per_event":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Evar goal_result,goal_key=\"goalc\";if(!(goal_result=(new RegExp(\"(?:^|; )\"+encodeURIComponent(goal_key)+\"\\x3d([^;]*)\")).exec(document.cookie))||!goal_result[1]){var td=new Date;td.setTime(td.getTime()+1728E5);document.cookie=\"goalc\\x3dCAMPAIGNTEST; expires\\x3d\"+td.toGMTString()+\"; path\\x3d\/\"};\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":74
    },{
      "function":"__html",
      "once_per_event":true,
      "vtp_html":"\n\u003Cscript type=\"text\/gtmscript\"\u003Evar syncFrame=document.createElement(\"iframe\");syncFrame.src=\"https:\/\/apvdr.com\/v2\/cs.php\";syncFrame.style.cssText=\"width:0px;height:0px;display:none;\";window.document.body.appendChild(syncFrame);\u003C\/script\u003E\n",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":75
    },{
      "function":"__html",
      "once_per_load":true,
      "vtp_html":"\u003Cscript type=\"text\/gtmscript\"\u003Evar reportPerformId=!0;\u003C\/script\u003E",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":76
    },{
      "function":"__html",
      "once_per_event":true,
      "vtp_html":"https:\/\/stags.bluekai.com\/site\/53496?phint=advertiser%3D%57946641phint=event%3Dimp\u0026amp;phint=adtype%3DContent",
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":79
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":["template","\u003Cimg src=\"https:\/\/tag.researchnow.com\/t\/beacon?adn=1\u0026amp;ca=microsoft\u0026amp;cr=",["escape",["macro",8],12],"\u0026amp;ord=",["escape",["macro",41],12],"\u0026amp;pl=TOTW_1\u0026amp;pr=284527\u0026amp;si=",["escape",["macro",30],12],"\"\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":168
    }],
  "predicates":[{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"Player Load"
    },{
      "function":"_re",
      "arg0":["macro",1],
      "arg1":"Player Load*"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"Video Start"
    },{
      "function":"_re",
      "arg0":["macro",1],
      "arg1":"Video Start*"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"Video End"
    },{
      "function":"_re",
      "arg0":["macro",1],
      "arg1":"Video End*"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"Advert Start"
    },{
      "function":"_re",
      "arg0":["macro",1],
      "arg1":"Advert Start*"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"Advert End"
    },{
      "function":"_re",
      "arg0":["macro",1],
      "arg1":"Advert End*"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"Enable Lightbox"
    },{
      "function":"_re",
      "arg0":["macro",1],
      "arg1":"Enable Lightbox*"
    },{
      "function":"_cn",
      "arg0":["macro",2],
      "arg1":"Premier League News"
    },{
      "function":"_re",
      "arg0":["macro",2],
      "arg1":"Reuters|Rugby News|South American football|WTA|AFL News 247|Asian club football news|ATP World Tour|Australian football news|australian open|Autosport TV|Champions League News|Euro 2012|Europa League|European Tour|German Football Highlights|Goal.com|MLS|Olympic Sports Review|Olympic News Channel|PGA Tour|Premier League",
      "ignore_case":true
    },{
      "function":"_re",
      "arg0":["macro",13],
      "arg1":"EE012CE3DF9F4CDDA868C9C1DAFE51| EB65024D2DE94EEBBD7188788072E56C| 94c778ea-aef6-1ae1-e044-00212836b646| 59242A5B20D549FE9300448FA9897014| E3900DA0553044CDA163B2DCF927B9C2| 69CF724DFD24498CBAFC5637DBD16C39| 0366d3e241104ab1bacf5372b73dbfe1| 2d8758f9-c8d4-44ca-8b82-17b3601fb9a3| 30B1BABF9E4C422A94CA8223DF0012EC| CE11BA1010914DF186BAB5B2B91CD213| C19D3D2D87BE4CC0A51B46038775D2BF| 51D0AAB9483E405190F56BEBB2FAED82| 95C62167089845F3A2BF2BBD2CB4935B| D418A7ABE64B4449E0440021281A8A86| 54b33c4b-13b5-46f6-9ca1-ee88de516e02| fb7bcbb9-b3d3-4689-834e-d7c8644b80cf| 1u6uwxag55ngf1bjc00htxo1l1| EDEA80A4864940C8BE27DCF43C039ED4| 6AF8CF8D52C14A06BB4E8FA2E998BD91| 45a43033749b424ea0dcac3c99d6d772| 2EE7CFF169D54C739901A1BCEB16EB37| 87475d2c-e831-4fc3-b059-f363b0ea7c8d| 66D8513DC7AA4732A394002C58D37F55| 26d2221c-8917-468e-bc22-ab406a621544| bcafafcd-1b78-4d93-ba37-9a99f05d6ad2| 9EBA1139EF334ECBA03DFBAAEAFC1BB7| b1e82e57b7604972b52d56a9598d1131| 43A34E32329F4A4A99E300E727796C44| CD2FF2CFBF0066F3E0440021281A8A86| D14910F9A47C3A3CE0440021281A8A86| 94c82525-2872-660e-e044-00144f78ddec| 94c778ea-aee7-1ae1-e044-00212836b646| 964985e1-76d5-4a3a-e044-002128369326| 94c778ea-aee6-1ae1-e044-00212836b646| dd8628c1-4c23-424c-a8a3-aee5440c3582| b4fcdcb1-b2cb-4cb5-961e-d9476284f1e7| C26FC59C977F483CE0440021281A8A86| 4CEF66AA7BE0471AB1E7671CB294D574| 1g5lijluc88lx1bzro7636w9xq| 94c778ea-aef7-1ae1-e044-00212836b646| 21twkszta8o11naxl3e7oqn80| 1jhfzeydx7tcr10byrkoqn8t1d| d3eon5g0tghw1maasrfg7plc1| k88c02r2l5fe1mlmgq6dgc110| 0304565f1dc64a34b8b6f94f6b90267f| 237bbfb5521149e7854a3e26ebacd928| 109ssimrciar01spqsfkjfwa68| 16jd8s8juhvvw19f6jc2j9ks4w| uqr7b2nyqbhm133w254g855pf| 1qyftfwafou5c187xddi85eatq| C4A4E60EE6AC2EB3E0440021281A8A86| 3c6b65c1-edee-4186-b48e-3bfc1d341ac5| 1ued5eviqtgvs1czhz1xwc334w| 7svpt7ddua0u12bgwss60xhec| 9e9495d8-a31f-49ff-b1f8-b32646ab3c70| 1wya775gyqpvl1ijwi8b56mexm| 8d9c11c0-72c5-4851-b59e-cd80ce9aa10f| 4AC18ECD2A7B4128AE80D87F50A5E75| cbe68d40-7407-4e5d-a939-c0071f38f331| 96f48fbc-0091-4996-b886-dd316e221791| A67BE23AE9464A9791FCA13D7F345059| BA887830B7E147E2A4B37F00892C9B79| 73ACF0688FEF4BA494E30432711D7227| c9021434-00cb-4549-9154-f8ebb166570b| 488AAE72FF434C45A6ABB519F15A565| bcb52e6341ed4915bf9e0ecba8f1ec5b| D8191E909A904A72A1FD361CDA4C25BE| 58BCD2B098AD4752A43D2B5164279BE2| bfc8b66d5e0448f48c23b664c7cc81c4",
      "ignore_case":true
    },{
      "function":"_re",
      "arg0":["macro",13],
      "arg1":"EDFBD613600149D8A129412389257401| 6F4900A75ECE431BA962BA422C3F7B99| 2b5d36c6-apmq-4632-c36f-f51f23e23897| cd42dacd-c117-49e5-8768-5bd6e1c00b4e| 9DB6FB2AAA214CC397B9DAC5076438BD| 148e4d8b-bf57-4744-a048-02732f0c2b13| 7efa08d4-1680-4b56-a8b0-4f6387ce762a| 3F805C6892204C4200CE4B47EA727D5C| 1pna43a1408db14xi5um96c4cw| 9c43c335-fe0f-4821-a4b5-48a811950d3c| dd571c06-4299-44c9-9da8-2c497423693c| 3612c960-deba-4d48-8ca6-d00209cbebd1| 2E8BE2B89ADF4D80AE05DEE2AC46C608| 915y0ajg912o1dwevlj5h5t8q| dfad873868d74cd3842556ca5786f2a0| df55db71-bd6c-4100-8c46-215f35709e3e| ACC896A0FE484AB38518A0D0B7EB7795| 702c6f84-870e-4af8-9b73-2c52ff49100b| 043a0ea5-7f79-400b-bfd6-fc8a8bef8a58| a234f1599e0a4576848ead30d0645d6d| E52B3F9552304B22B5C2C6817E8A6F3| BB3418687C224BA389B6DCDDCEC24B21| 08ef635b2b314121adc8e99610e88ad3| f93db6150d374855a5c5667183b4220d| 112e6d4b-59e7-475a-94f0-76c1ed4925d3| d796ab84-cc9b-4832-8e75-6d9084744922| CACDE48F929141D800B172C4784B2DBB| 4aed341a-35c3-4c66-a8fa-5ff98aa1c878| C777F41B835A62CBE0440021281A8A86| 9CE5CA2A181A49C6ADCA3E1EEA938C9| 877345d2c0df429d9ea9ebba075648dc| 4DBD4E8099734AA8AA981977B6DAC893| 64a03807-5fbe-4029-9752-1ffff0840073| 8E3B9452E2E4476A9DAA79FE51E8969D| 81AD474010F04897A8173420635BC3D3| 0560844CC25D4CCA85A2FDA09DF107A| b6f47144-d428-4d4c-ad63-31a578158cbe| 792c8482-cbf8-4ecb-ab78-39f9f3ac977a| 3888B3EABD4042A1BA99906992BD52B| C698E77785DF40C2BBE07658F4FC7BC7| E9A64FD5C8FF4CE6B2688E1CEDB01F64| 0FAA7971C4CE48AC944F9D9B172FE000| 157B8E03A82B4F4EA8D7CFB287F95EFB| C9F4AB6BE4C74BCB83BD9F53DC444FB1| CBE5ADED65664C51A3215914EA7B1CF4| C6F2505BEF524BD28E7FFABCB9A0BAE| A03C2C52555145249EFE84F8008D005E| 14es20kw2r29t1fuwxl29y650x| 4C60DE166B174F32AF00DDB5F45B424C| BFBFEF9DF9285CEDE0440021281A8A86| 19072A66DEE7437EAC5CF39C37E00C1| 65C1929B74A248F797A1C6F4F2BA141D| 3c6e47d7-677b-5743-b25e-g62g34f34908| 4cbea7c5-f796-4c00-aaf1-73ac5118fdf9| 56615e33-43db-46f7-a669-763fbf1f8f86| 3f4073ac-0526-44b2-b753-b3311d1fea5c| CFB8125822753524E0440021281A8A86| A47133C5792843998E62E1D583101DC9| 2b5d36c6-677b-4632-b25e-g62g34f34908| 0208A7B4E086436481D8E5ECAA08EC49| 6279888DA4004224A525A38637DB3C94| 59a513b7-b408-4089-94d2-528276b9f76b| 833EE1D4E72E4814BE127D192BB70380| 2b4c25c6-677b-4632-b25e-f59e12d13897| CFB8125822673524E0440021281A8A86| 61B9330E129744FE9472AD1B9E2EF695| e22d811dce894b8b945bb699e3fe2e67| 173EC4FBFAC7461AB1B8CD582E2CF11D| C91AF87A9C9A1C7EE0440021281A8A86",
      "ignore_case":true
    },{
      "function":"_re",
      "arg0":["macro",13],
      "arg1":"C8F0F889B34D2663E0440021281A8A86| 25166C3CF4874F9D006E8EB7D601F553| 44884D704DA24ED295D415A58B9CD7E1| EFACBD6F79C6439DB4BDAE6CF7031FA1| 573ea86c-0834-48c0-bab4-d0453a3fd901| d67d6b17-7079-4efd-9451-b78443b22101| f5ba2053-cc46-43cf-bf8a-14f978a7ca3b| C116F97E88813B1CE0440021281A8A86| 29607c5d-0c13-4356-b3a8-ea1ba4c403c5| C26FC59C9779483CE0440021281A8A86| C4473D7CA3E4464BB37427E0BB13D300| 1d5cfeb3-507e-49ab-bcb5-5add0f610ac7| C116F97E887F3B1CE0440021281A8A86| 9DDE06B2D5D642F8A893F6CE0004195E| kkl68yd3vft1150g4sckkngmk| 94c778ea-aeed-1ae1-e044-00212836b646| 0162FC2C1EB84442BFB2A7515D34CFC2| 2FCC3D09B0604930BF7693E2714CA0E| 9h1ooj7hp7igz3uu4kinirm9| 4e9ppqigzgou1p9z0ytsyu8kk| 11y3cekxl1mbm148rvcd9qrxjw| 411E6713656D41B4B6ACBA2DECE500F0| ef43b6df-1582-4125-8fea-f515d82491f5| 9r7m3d8540j115e1w7bnhtilf| 714b07fa-5630-44dd-8b22-454998ddeaa7| 9AE55DE617A24DFAB82F5147DB1F1379| 3f61f23c-b816-4c49-aa0d-c901f66d7a4e| 1c89cc35c9654f6f983c2042e48dccc5| C91AF87A9CA21C7EE0440021281A8A86| C8F10641B7CF3ABFE0440021281A8A86| C903F4E7C8F463E8E0440021281A8A86| 3C42ED4180484C16A4FF1FAD84D75454| 4433d958-7e69-449b-859f-5ccf823ecc1d| 8CCC45EAFD214897944BB838CCF9741| C8CA76AC0F09481CE0440021281A8A86| 984ED4C410114258B09731416DA88F88| 2C20408283D043CDB0D6309B90720D2| 664311c70afb4ebb8b5364a108e2ceb4| C116F97E88853B1CE0440021281A8A86| 39043faa-c516-4041-9521-148df388a4ea| a1ab41c1-163a-4925-8a38-3e909fb85160| 4A5AE91B634147F8914BB298C9C8685D| 87B6FC0E1C5D4AA1A852BF86F7909C16| C91AF87A9CA41C7EE0440021281A8A86| f8e3f63c-9cc0-47b9-a468-767b7ae8dea8| 9D97AA0F914161B0E04400212836B646| F9E62AE29BB94654BD50F100003843F7| 497fc0d7-4dbe-4051-8316-d6f318d408d2| 0C61B787B95449039445B0ABCB64A558| h4ceot4wwlcd1270s2gcde27d| F4AD87CF7892436984BCE9D49349E000| 04abf6447baa4dbbb085bd02c4da4140| 41960E4D057B46FAA9CDD532AC73D847| twzv2t7xze2z1fertcegkkqts| 1ojepvmzrujhm1xrc2nnam0qqi| 8eba9649324b4172bb547f40cc2bb50a| 1u4qm53koy70o1i8i91pb4v3w2| 47d1b911a77c43c7ae785d7b296b433a| b46562e4-e507-4e1a-9cad-579f4ba29039| aa043432-8d2e-431f-ab08-eded0ecfb0bb| 94c778ea-aef3-1ae1-e044-00212836b646| 5cd3fd7d-0951-4678-8783-c9b64fe9c4af| yo06p5f5jm4a1v78woxkp8d20| 2b6513d3-c0ed-433c-a646-3f98c58b4ff7| 1k59w758rl9hm1p7fvv69u4gs7| 620dff2492d84f3eadcd808ef5676d70| 6e38810f-d7d1-4556-8d66-9a1310eeef88| D571ED3D94484FA5B08934709D06B8C0| 447405551AA5404C83E32663CB79C341",
      "ignore_case":true
    },{
      "function":"_re",
      "arg0":["macro",2],
      "arg1":"World Cup News|World Twenty20 News",
      "ignore_case":true
    },{
      "function":"_re",
      "arg0":["macro",13],
      "arg1":"C26FC59C978F483CE0440021281A8A86| FD9BFBC456904EFDB31F6CF793CA6264| 5BF341EC847C431289C41B0054009487| 87C10ECCD4344D6097C85EF8354EF7B| D02B9553D7A5452792D4CC92219FDD1| 42E71518148C4263BF725E7375A82378| 3c65b907-190d-4c4f-96c2-ffa3a3ba1aae| 03E7425F7D95489AA5FBEEF3B9F564F| BBF9C97575E14CBBB018816273C312E7| 36414aa0-09f3-4c94-9cb9-7cc1cfeda48a| ae967e71-8f01-4023-9cca-27b0485402ab| ljj3eneni3u41bj7m43u7riq0| D07EAC7FA919413EE0440021281A8A86| D003ECD43F080237E0440021281A8A86| CFB81258227B3524E0440021281A8A86| 4f5bfc2b585c4237ac1465f12a5b1634| 60C73E3EB6994340B1C054FEA90C500| aec7e34a556e41bb89c6f9ff00407c14| wkog5f107mr61tp5eu3iat29o| 6k4zdmwlp79x1gnptebsr4bpp| 41719FFF14834E71A82187A73FFB35D0| 7F06F87E4E794EF2A5020503EB57247D| 60A7A7295B304B30A278882ED00A3B4| f9792942-4609-481a-97303-4cabb5ab4006| 1ap99rqpokr5z1igm0ddixccgs| d12f0cdb-1833-4267-ad47-c4d08bb2000d| D50A6228EED26A84E0440021281A8A86| 29B01F2AECFC458AB1DAA2D13EF412A6| 0e721d53-f723-43ba-a27c-1a7e3a0d65b3| 53c2108d-5378-45a3-9cce-190bab8de3df| 8145fb43-0e7f-4794-94a3-aac049bd699e| ED58197E1735424CAC94FEF89DBBE164| 518b096d-9b25-4bf5-af75-8f6118d637e1| 9202913C050C4318A8CF783B52DC4E94| 6D33AA425AE74CB380D37C5744439B43| DC30C58908D44BB8BBF77DEC8334E588| 1653t3b4z56rj1gr7m9f6jm26w| 9331159e-cb7b-4cd9-9e33-125975641b58| D46C9AE0A05121E5E0440021281A8A86| 0DD952CC97CE4402AE004E58C0DD75E7| 44FB7AD06FFC4C1BA061F173002010F0| 00db5197fb7a4b07a255eb81e4bf5490| a871ef2f687240f6bf884842b61007a6| 94c778ea-aef5-1ae1-e044-00212836b646| 8189F8C192134D17BD1CBD354B128DF7| 585E3A999116484B9E23E7CB4F7DA12D| C26FC59C9795483CE0440021281A8A86| C91AF87A9C961C7EE0440021281A8A86| C7680D485B734D67AE06221E513FCF41| E9D256F54119471BB65B2D548111573E| 1f773d98-8e7c-4633-93a4-9f74eb68c1b8| 36a7609997ca403599ffea3435ad4644| E6769F5884694FA39282A8C7CE9D2131| 2dac3292c836446b9f4bcffb0693114b| 67bb4767-35c3-4512-a19e-6af19032378c| 778A769038814D28B46F87F7F85DE8B0| c7ef7b6f-92e5-4aa6-a76f-631ede8f3e0e| 5B2B13E13FDE4231A0AD41E602ECE24E| 96A71ECA0B8F4FAFA267C4637628E83B| FA49C8230E1A447FB3A4AC869C27F935| a7d148c5-c13a-4c61-ac68-c57e6c7d0bbe| 3d792e04-87e1-43f7-ba87-3e75973f6781| 7011376115EE4023BEA3567F1007E0D3| 2423516c-9a87-4692-aac2-2251b6969d99| F8608167456E4D5F8B197B21910227C9| 3bc7489c-577d-4d5b-a5b3-04d819cd28e6| a0e22eadc9e74d09af115b26696f18bb| 316e44a5-996e-4e15-a4b0-34c73d70e11b| 78AED69A3DBF44D6A337E0CB1034865B",
      "ignore_case":true
    },{
      "function":"_re",
      "arg0":["macro",15],
      "arg1":"Omnisport",
      "ignore_case":true
    },{
      "function":"_re",
      "arg0":["macro",15],
      "arg1":"Reuters_News",
      "ignore_case":true
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"Twitter"
    },{
      "function":"_re",
      "arg0":["macro",1],
      "arg1":"Twitter*"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"Facebook"
    },{
      "function":"_re",
      "arg0":["macro",1],
      "arg1":"Facebook*"
    },{
      "function":"_eq",
      "arg0":["macro",4],
      "arg1":"13723"
    },{
      "function":"_eq",
      "arg0":["macro",5],
      "arg1":"CP"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"Play"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"Play More"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"Pause"
    },{
      "function":"_re",
      "arg0":["macro",1],
      "arg1":"Pause"
    },{
      "function":"_eq",
      "arg0":["macro",4],
      "arg1":"13801"
    },{
      "function":"_re",
      "arg0":["macro",4],
      "arg1":"13723|13564",
      "ignore_case":true
    },{
      "function":"_eq",
      "arg0":["macro",14],
      "arg1":"ep4m"
    },{
      "function":"_eq",
      "arg0":["macro",11],
      "arg1":"13723"
    },{
      "function":"_eq",
      "arg0":["macro",14],
      "arg1":"ep3"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"Enable Full Screen"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"Enable Full Screen"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"Close Full Screen"
    },{
      "function":"_re",
      "arg0":["macro",1],
      "arg1":"Close Full Screen"
    },{
      "function":"_re",
      "arg0":["macro",1],
      "arg1":"Player_Blocked"
    },{
      "function":"_cn",
      "arg0":["macro",6],
      "arg1":"JP"
    },{
      "function":"_cn",
      "arg0":["macro",30],
      "arg1":"goal.com"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"JP Merger trigger"
    },{
      "function":"_cn",
      "arg0":["macro",0],
      "arg1":"Player_Replay"
    },{
      "function":"_re",
      "arg0":["macro",1],
      "arg1":"Player_Replay"
    },{
      "function":"_re",
      "arg0":["macro",6],
      "arg1":"US|CA"
    },{
      "function":"_re",
      "arg0":["macro",1],
      "arg1":"Start"
    },{
      "function":"_eq",
      "arg0":["macro",4],
      "arg1":"13564"
    },{
      "function":"_eq",
      "arg0":["macro",0],
      "arg1":"Play"
    },{
      "function":"_cn",
      "arg0":["macro",7],
      "arg1":"bild.de\/sport\/fussball\/premierleague\/diese-england-videos-muessen-sie-sehen"
    },{
      "function":"_cn",
      "arg0":["macro",5],
      "arg1":"CP"
    },{
      "function":"_re",
      "arg0":["macro",1],
      "arg1":"Play*"
    },{
      "function":"_re",
      "arg0":["macro",1],
      "arg1":"ePlayer Region"
    },{
      "function":"_eq",
      "arg0":["macro",26],
      "arg1":"true"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"Player Load"
    },{
      "function":"_eq",
      "arg0":["macro",25],
      "arg1":"false"
    },{
      "function":"_eq",
      "arg0":["macro",12],
      "arg1":"s2ztvawzayw61k0ocvajbo1ct"
    },{
      "function":"_cn",
      "arg0":["macro",26],
      "arg1":"false"
    },{
      "function":"_eq",
      "arg0":["macro",1],
      "arg1":"IBM Video"
    },{
      "function":"_re",
      "arg0":["macro",12],
      "arg1":"7tw44l6bufco1ukmlege6stpk|18czvix4j2aek16mpjkxodsaf1"
    }],
  "rules":[
    [["if",0,1],["add",0,20,27,30,31,32]],
    [["if",2,3],["add",1,22,25,28]],
    [["if",4,5],["add",2,25]],
    [["if",6,7],["add",3,22,29]],
    [["if",8,9],["add",4]],
    [["if",10,11],["add",5,6]],
    [["if",2,3,12],["add",7]],
    [["if",2,3,13],["add",7]],
    [["if",2,3,14],["add",7]],
    [["if",2,3,15],["add",7]],
    [["if",2,3,16],["add",7]],
    [["if",2,3,17],["add",7]],
    [["if",2,3,18],["add",7]],
    [["if",21,22],["add",8]],
    [["if",23,24],["add",9]],
    [["if",25,26,27],["add",10]],
    [["if",25,28],["add",10]],
    [["if",2,3,19],["add",11],["block",7]],
    [["if",29,30],["add",12]],
    [["if",26,27,31],["add",13]],
    [["if",28,31],["add",13]],
    [["if",2,3,32],["add",14]],
    [["if",25,26,27,33],["add",15]],
    [["if",28,33,34],["add",15]],
    [["if",25,26,27,35],["add",16]],
    [["if",25,28,35],["add",16]],
    [["if",36,37],["add",17]],
    [["if",38,39],["add",18]],
    [["if",40],["add",19]],
    [["if",44,45],["add",21]],
    [["if",46,47],["add",23],["block",22]],
    [["if",26,27,48],["add",24]],
    [["if",28,48],["add",24]],
    [["if",49,50,51,52],["add",26]],
    [["if",41,53],["add",32]],
    [["if",0,54,55],["add",33]],
    [["if",0,55,56],["add",33]],
    [["if",57,59],["unless",58],["add",34]],
    [["if",2,3,60],["add",35]],
    [["if",2,3,20],["block",7,11]],
    [["if",41,42,43],["block",20]]]
},
"runtime":[]




};
/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var ba,ca="function"==typeof Object.create?Object.create:function(a){var b=function(){};b.prototype=a;return new b},da;if("function"==typeof Object.setPrototypeOf)da=Object.setPrototypeOf;else{var ea;a:{var fa={Mf:!0},ha={};try{ha.__proto__=fa;ea=ha.Mf;break a}catch(a){}ea=!1}da=ea?function(a,b){a.__proto__=b;if(a.__proto__!==b)throw new TypeError(a+" is not extensible");return a}:null}var ia=da,ja=this||self,la=/^[\w+/_-]+[=]{0,2}$/,na=null;var oa=function(){},pa=function(a){return"function"==typeof a},g=function(a){return"string"==typeof a},qa=function(a){return"number"==typeof a&&!isNaN(a)},ra=function(a){return"[object Array]"==Object.prototype.toString.call(Object(a))},ta=function(a,b){if(Array.prototype.indexOf){var c=a.indexOf(b);return"number"==typeof c?c:-1}for(var d=0;d<a.length;d++)if(a[d]===b)return d;return-1},va=function(a,b){if(a&&ra(a))for(var c=0;c<a.length;c++)if(a[c]&&b(a[c]))return a[c]},wa=function(a,b){if(!qa(a)||
!qa(b)||a>b)a=0,b=2147483647;return Math.floor(Math.random()*(b-a+1)+a)},ya=function(a,b){for(var c=new xa,d=0;d<a.length;d++)c.set(a[d],!0);for(var e=0;e<b.length;e++)if(c.get(b[e]))return!0;return!1},za=function(a,b){for(var c in a)Object.prototype.hasOwnProperty.call(a,c)&&b(c,a[c])},Aa=function(a){return Math.round(Number(a))||0},Ba=function(a){return"false"==String(a).toLowerCase()?!1:!!a},Ca=function(a){var b=[];if(ra(a))for(var c=0;c<a.length;c++)b.push(String(a[c]));return b},Da=function(a){return a?
a.replace(/^\s+|\s+$/g,""):""},Fa=function(){return(new Date).getTime()},xa=function(){this.prefix="gtm.";this.values={}};xa.prototype.set=function(a,b){this.values[this.prefix+a]=b};xa.prototype.get=function(a){return this.values[this.prefix+a]};
var Ga=function(a,b,c){return a&&a.hasOwnProperty(b)?a[b]:c},Ha=function(a){var b=!1;return function(){if(!b)try{a()}catch(c){}b=!0}},Ia=function(a,b){for(var c in b)b.hasOwnProperty(c)&&(a[c]=b[c])},Ja=function(a){for(var b in a)if(a.hasOwnProperty(b))return!0;return!1},Ka=function(a,b){for(var c=[],d=0;d<a.length;d++)c.push(a[d]),c.push.apply(c,b[a[d]]||[]);return c},Ma=function(a,b){for(var c={},d=c,e=a.split("."),f=0;f<e.length-1;f++)d=d[e[f]]={};d[e[e.length-1]]=b;return c},Na=function(a){var b=
[];za(a,function(c,d){10>c.length&&d&&b.push(c)});return b.join(",")};/*
 jQuery v1.9.1 (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license. */
var Oa=/\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,Pa=function(a){if(null==a)return String(a);var b=Oa.exec(Object.prototype.toString.call(Object(a)));return b?b[1].toLowerCase():"object"},Ra=function(a,b){return Object.prototype.hasOwnProperty.call(Object(a),b)},Sa=function(a){if(!a||"object"!=Pa(a)||a.nodeType||a==a.window)return!1;try{if(a.constructor&&!Ra(a,"constructor")&&!Ra(a.constructor.prototype,"isPrototypeOf"))return!1}catch(c){return!1}for(var b in a);return void 0===
b||Ra(a,b)},n=function(a,b){var c=b||("array"==Pa(a)?[]:{}),d;for(d in a)if(Ra(a,d)){var e=a[d];"array"==Pa(e)?("array"!=Pa(c[d])&&(c[d]=[]),c[d]=n(e,c[d])):Sa(e)?(Sa(c[d])||(c[d]={}),c[d]=n(e,c[d])):c[d]=e}return c};
var Ta=[],Ua={"\x00":"&#0;",'"':"&quot;","&":"&amp;","'":"&#39;","<":"&lt;",">":"&gt;","\t":"&#9;","\n":"&#10;","\x0B":"&#11;","\f":"&#12;","\r":"&#13;"," ":"&#32;","-":"&#45;","/":"&#47;","=":"&#61;","`":"&#96;","\u0085":"&#133;","\u00a0":"&#160;","\u2028":"&#8232;","\u2029":"&#8233;"},Va=function(a){return Ua[a]},Wa=/[\x00\x22\x26\x27\x3c\x3e]/g;var $a=/[\x00\x08-\x0d\x22\x26\x27\/\x3c-\x3e\\\x85\u2028\u2029]/g,ab={"\x00":"\\x00","\b":"\\x08","\t":"\\t","\n":"\\n","\x0B":"\\x0b",
"\f":"\\f","\r":"\\r",'"':"\\x22","&":"\\x26","'":"\\x27","/":"\\/","<":"\\x3c","=":"\\x3d",">":"\\x3e","\\":"\\\\","\u0085":"\\x85","\u2028":"\\u2028","\u2029":"\\u2029",$:"\\x24","(":"\\x28",")":"\\x29","*":"\\x2a","+":"\\x2b",",":"\\x2c","-":"\\x2d",".":"\\x2e",":":"\\x3a","?":"\\x3f","[":"\\x5b","]":"\\x5d","^":"\\x5e","{":"\\x7b","|":"\\x7c","}":"\\x7d"},bb=function(a){return ab[a]};Ta[7]=function(a){return String(a).replace($a,bb)};
var jb=/['()]/g,kb=function(a){return"%"+a.charCodeAt(0).toString(16)};Ta[12]=function(a){var b=
encodeURIComponent(String(a));jb.lastIndex=0;return jb.test(b)?b.replace(jb,kb):b};var lb=/[\x00- \x22\x27-\x29\x3c\x3e\\\x7b\x7d\x7f\x85\xa0\u2028\u2029\uff01\uff03\uff04\uff06-\uff0c\uff0f\uff1a\uff1b\uff1d\uff1f\uff20\uff3b\uff3d]/g,mb={"\x00":"%00","\u0001":"%01","\u0002":"%02","\u0003":"%03","\u0004":"%04","\u0005":"%05","\u0006":"%06","\u0007":"%07","\b":"%08","\t":"%09","\n":"%0A","\x0B":"%0B","\f":"%0C","\r":"%0D","\u000e":"%0E","\u000f":"%0F","\u0010":"%10",
"\u0011":"%11","\u0012":"%12","\u0013":"%13","\u0014":"%14","\u0015":"%15","\u0016":"%16","\u0017":"%17","\u0018":"%18","\u0019":"%19","\u001a":"%1A","\u001b":"%1B","\u001c":"%1C","\u001d":"%1D","\u001e":"%1E","\u001f":"%1F"," ":"%20",'"':"%22","'":"%27","(":"%28",")":"%29","<":"%3C",">":"%3E","\\":"%5C","{":"%7B","}":"%7D","\u007f":"%7F","\u0085":"%C2%85","\u00a0":"%C2%A0","\u2028":"%E2%80%A8","\u2029":"%E2%80%A9","\uff01":"%EF%BC%81","\uff03":"%EF%BC%83","\uff04":"%EF%BC%84","\uff06":"%EF%BC%86",
"\uff07":"%EF%BC%87","\uff08":"%EF%BC%88","\uff09":"%EF%BC%89","\uff0a":"%EF%BC%8A","\uff0b":"%EF%BC%8B","\uff0c":"%EF%BC%8C","\uff0f":"%EF%BC%8F","\uff1a":"%EF%BC%9A","\uff1b":"%EF%BC%9B","\uff1d":"%EF%BC%9D","\uff1f":"%EF%BC%9F","\uff20":"%EF%BC%A0","\uff3b":"%EF%BC%BB","\uff3d":"%EF%BC%BD"},ob=function(a){return mb[a]};var qb;
var rb=[],sb=[],tb=[],ub=[],vb=[],wb={},xb,yb,zb,Ab=function(a,b){var c={};c["function"]="__"+a;for(var d in b)b.hasOwnProperty(d)&&(c["vtp_"+d]=b[d]);return c},Bb=function(a,b){var c=a["function"];if(!c)throw Error("Error: No function name given for function call.");var d=wb[c],e={},f;for(f in a)a.hasOwnProperty(f)&&0===f.indexOf("vtp_")&&(e[void 0!==d?f:f.substr(4)]=a[f]);return void 0!==d?d(e):qb(c,e,b)},Eb=function(a,b,c){c=c||[];var d={},e;for(e in a)a.hasOwnProperty(e)&&(d[e]=Db(a[e],b,c));
return d},Fb=function(a){var b=a["function"];if(!b)throw"Error: No function name given for function call.";var c=wb[b];return c?c.priorityOverride||0:0},Db=function(a,b,c){if(ra(a)){var d;switch(a[0]){case "function_id":return a[1];case "list":d=[];for(var e=1;e<a.length;e++)d.push(Db(a[e],b,c));return d;case "macro":var f=a[1];if(c[f])return;var h=rb[f];if(!h||b.Yc(h))return;c[f]=!0;try{var k=Eb(h,b,c);k.vtp_gtmEventId=b.id;d=Bb(k,b);zb&&(d=zb.mg(d,k))}catch(y){b.Ge&&b.Ge(y,Number(f)),d=!1}c[f]=
!1;return d;case "map":d={};for(var l=1;l<a.length;l+=2)d[Db(a[l],b,c)]=Db(a[l+1],b,c);return d;case "template":d=[];for(var m=!1,p=1;p<a.length;p++){var r=Db(a[p],b,c);yb&&(m=m||r===yb.Kb);d.push(r)}return yb&&m?yb.pg(d):d.join("");case "escape":d=Db(a[1],b,c);if(yb&&ra(a[1])&&"macro"===a[1][0]&&yb.Pg(a))return yb.hh(d);d=String(d);for(var u=2;u<a.length;u++)Ta[a[u]]&&(d=Ta[a[u]](d));return d;case "tag":var q=a[1];if(!ub[q])throw Error("Unable to resolve tag reference "+q+".");return d={te:a[2],
index:q};case "zb":var t={arg0:a[2],arg1:a[3],ignore_case:a[5]};t["function"]=a[1];var v=Gb(t,b,c),w=!!a[4];return w||2!==v?w!==(1===v):null;default:throw Error("Attempting to expand unknown Value type: "+a[0]+".");}}return a},Gb=function(a,b,c){try{return xb(Eb(a,b,c))}catch(d){JSON.stringify(a)}return 2};var Hb=function(){var a=function(b){return{toString:function(){return b}}};return{Cd:a("convert_case_to"),Dd:a("convert_false_to"),Ed:a("convert_null_to"),Fd:a("convert_true_to"),Gd:a("convert_undefined_to"),Oh:a("debug_mode_metadata"),ya:a("function"),kf:a("instance_name"),qf:a("live_only"),sf:a("malware_disabled"),tf:a("metadata"),Ph:a("original_vendor_template_id"),xf:a("once_per_event"),Nd:a("once_per_load"),Vd:a("setup_tags"),Xd:a("tag_id"),Yd:a("teardown_tags")}}();var Ib=null,Lb=function(a){function b(r){for(var u=0;u<r.length;u++)d[r[u]]=!0}var c=[],d=[];Ib=Jb(a);for(var e=0;e<sb.length;e++){var f=sb[e],h=Kb(f);if(h){for(var k=f.add||[],l=0;l<k.length;l++)c[k[l]]=!0;b(f.block||[])}else null===h&&b(f.block||[])}for(var m=[],p=0;p<ub.length;p++)c[p]&&!d[p]&&(m[p]=!0);return m},Kb=function(a){for(var b=a["if"]||[],c=0;c<b.length;c++){var d=Ib(b[c]);if(0===d)return!1;if(2===d)return null}for(var e=a.unless||[],f=0;f<e.length;f++){var h=Ib(e[f]);if(2===h)return null;
if(1===h)return!1}return!0},Jb=function(a){var b=[];return function(c){void 0===b[c]&&(b[c]=Gb(tb[c],a));return b[c]}};/*
 Copyright (c) 2014 Derek Brans, MIT license https://github.com/krux/postscribe/blob/master/LICENSE. Portions derived from simplehtmlparser, which is licensed under the Apache License, Version 2.0 */

var ec,fc=function(){};(function(){function a(k,l){k=k||"";l=l||{};for(var m in b)b.hasOwnProperty(m)&&(l.$f&&(l["fix_"+m]=!0),l.ve=l.ve||l["fix_"+m]);var p={comment:/^\x3c!--/,endTag:/^<\//,atomicTag:/^<\s*(script|style|noscript|iframe|textarea)[\s\/>]/i,startTag:/^</,chars:/^[^<]/},r={comment:function(){var q=k.indexOf("--\x3e");if(0<=q)return{content:k.substr(4,q),length:q+3}},endTag:function(){var q=k.match(d);if(q)return{tagName:q[1],length:q[0].length}},atomicTag:function(){var q=r.startTag();
if(q){var t=k.slice(q.length);if(t.match(new RegExp("</\\s*"+q.tagName+"\\s*>","i"))){var v=t.match(new RegExp("([\\s\\S]*?)</\\s*"+q.tagName+"\\s*>","i"));if(v)return{tagName:q.tagName,S:q.S,content:v[1],length:v[0].length+q.length}}}},startTag:function(){var q=k.match(c);if(q){var t={};q[2].replace(e,function(v,w,y,x,A){var B=y||x||A||f.test(w)&&w||null,z=document.createElement("div");z.innerHTML=B;t[w]=z.textContent||z.innerText||B});return{tagName:q[1],S:t,Db:!!q[3],length:q[0].length}}},chars:function(){var q=
k.indexOf("<");return{length:0<=q?q:k.length}}},u=function(){for(var q in p)if(p[q].test(k)){var t=r[q]();return t?(t.type=t.type||q,t.text=k.substr(0,t.length),k=k.slice(t.length),t):null}};l.ve&&function(){var q=/^(AREA|BASE|BASEFONT|BR|COL|FRAME|HR|IMG|INPUT|ISINDEX|LINK|META|PARAM|EMBED)$/i,t=/^(COLGROUP|DD|DT|LI|OPTIONS|P|TD|TFOOT|TH|THEAD|TR)$/i,v=[];v.Ee=function(){return this[this.length-1]};v.$c=function(z){var E=this.Ee();return E&&E.tagName&&E.tagName.toUpperCase()===z.toUpperCase()};v.lg=
function(z){for(var E=0,H;H=this[E];E++)if(H.tagName===z)return!0;return!1};var w=function(z){z&&"startTag"===z.type&&(z.Db=q.test(z.tagName)||z.Db);return z},y=u,x=function(){k="</"+v.pop().tagName+">"+k},A={startTag:function(z){var E=z.tagName;"TR"===E.toUpperCase()&&v.$c("TABLE")?(k="<TBODY>"+k,B()):l.Yh&&t.test(E)&&v.lg(E)?v.$c(E)?x():(k="</"+z.tagName+">"+k,B()):z.Db||v.push(z)},endTag:function(z){v.Ee()?l.zg&&!v.$c(z.tagName)?x():v.pop():l.zg&&(y(),B())}},B=function(){var z=k,E=w(y());k=z;if(E&&
A[E.type])A[E.type](E)};u=function(){B();return w(y())}}();return{append:function(q){k+=q},oh:u,ei:function(q){for(var t;(t=u())&&(!q[t.type]||!1!==q[t.type](t)););},clear:function(){var q=k;k="";return q},fi:function(){return k},stack:[]}}var b=function(){var k={},l=this.document.createElement("div");l.innerHTML="<P><I></P></I>";k.ji="<P><I></P></I>"!==l.innerHTML;l.innerHTML="<P><i><P></P></i></P>";k.ii=2===l.childNodes.length;return k}(),c=/^<([\-A-Za-z0-9_]+)((?:\s+[\w\-]+(?:\s*=?\s*(?:(?:"[^"]*")|(?:'[^']*')|[^>\s]+))?)*)\s*(\/?)>/,
d=/^<\/([\-A-Za-z0-9_]+)[^>]*>/,e=/([\-A-Za-z0-9_]+)(?:\s*=\s*(?:(?:"((?:\\.|[^"])*)")|(?:'((?:\\.|[^'])*)')|([^>\s]+)))?/g,f=/^(checked|compact|declare|defer|disabled|ismap|multiple|nohref|noresize|noshade|nowrap|readonly|selected)$/i;a.J=b;a.K=function(k){var l={comment:function(m){return"<--"+m.content+"--\x3e"},endTag:function(m){return"</"+m.tagName+">"},atomicTag:function(m){return l.startTag(m)+m.content+l.endTag(m)},startTag:function(m){var p="<"+m.tagName,r;for(r in m.S){var u=m.S[r];p+=
" "+r+'="'+(u?u.replace(/(^|[^\\])"/g,'$1\\"'):"")+'"'}return p+(m.Db?"/>":">")},chars:function(m){return m.text}};return l[k.type](k)};a.o=function(k){var l={},m;for(m in k){var p=k[m];l[m]=p&&p.replace(/(^|[^\\])"/g,'$1\\"')}return l};for(var h in b)a.h=a.h||!b[h]&&h;ec=a})();(function(){function a(){}function b(r){return void 0!==r&&null!==r}function c(r,u,q){var t,v=r&&r.length||0;for(t=0;t<v;t++)u.call(q,r[t],t)}function d(r,u,q){for(var t in r)r.hasOwnProperty(t)&&u.call(q,t,r[t])}function e(r,
u){d(u,function(q,t){r[q]=t});return r}function f(r,u){r=r||{};d(u,function(q,t){b(r[q])||(r[q]=t)});return r}function h(r){try{return m.call(r)}catch(q){var u=[];c(r,function(t){u.push(t)});return u}}var k={Qf:a,Rf:a,Sf:a,Tf:a,ag:a,bg:function(r){return r},done:a,error:function(r){throw r;},rh:!1},l=this;if(!l.postscribe){var m=Array.prototype.slice,p=function(){function r(q,t,v){var w="data-ps-"+t;if(2===arguments.length){var y=q.getAttribute(w);return b(y)?String(y):y}b(v)&&""!==v?q.setAttribute(w,
v):q.removeAttribute(w)}function u(q,t){var v=q.ownerDocument;e(this,{root:q,options:t,Eb:v.defaultView||v.parentWindow,Qa:v,jc:ec("",{$f:!0}),Mc:[q],kd:"",ld:v.createElement(q.nodeName),Ab:[],Ga:[]});r(this.ld,"proxyof",0)}u.prototype.write=function(){[].push.apply(this.Ga,arguments);for(var q;!this.Tb&&this.Ga.length;)q=this.Ga.shift(),"function"===typeof q?this.gg(q):this.vd(q)};u.prototype.gg=function(q){var t={type:"function",value:q.name||q.toString()};this.fd(t);q.call(this.Eb,this.Qa);this.Le(t)};
u.prototype.vd=function(q){this.jc.append(q);for(var t,v=[],w,y;(t=this.jc.oh())&&!(w=t&&"tagName"in t?!!~t.tagName.toLowerCase().indexOf("script"):!1)&&!(y=t&&"tagName"in t?!!~t.tagName.toLowerCase().indexOf("style"):!1);)v.push(t);this.Jh(v);w&&this.Hg(t);y&&this.Ig(t)};u.prototype.Jh=function(q){var t=this.dg(q);t.je&&(t.Wc=this.kd+t.je,this.kd+=t.lh,this.ld.innerHTML=t.Wc,this.Gh())};u.prototype.dg=function(q){var t=this.Mc.length,v=[],w=[],y=[];c(q,function(x){v.push(x.text);if(x.S){if(!/^noscript$/i.test(x.tagName)){var A=
t++;w.push(x.text.replace(/(\/?>)/," data-ps-id="+A+" $1"));"ps-script"!==x.S.id&&"ps-style"!==x.S.id&&y.push("atomicTag"===x.type?"":"<"+x.tagName+" data-ps-proxyof="+A+(x.Db?" />":">"))}}else w.push(x.text),y.push("endTag"===x.type?x.text:"")});return{ki:q,raw:v.join(""),je:w.join(""),lh:y.join("")}};u.prototype.Gh=function(){for(var q,t=[this.ld];b(q=t.shift());){var v=1===q.nodeType;if(!v||!r(q,"proxyof")){v&&(this.Mc[r(q,"id")]=q,r(q,"id",null));var w=q.parentNode&&r(q.parentNode,"proxyof");
w&&this.Mc[w].appendChild(q)}t.unshift.apply(t,h(q.childNodes))}};u.prototype.Hg=function(q){var t=this.jc.clear();t&&this.Ga.unshift(t);q.src=q.S.src||q.S.Qh;q.src&&this.Ab.length?this.Tb=q:this.fd(q);var v=this;this.Ih(q,function(){v.Le(q)})};u.prototype.Ig=function(q){var t=this.jc.clear();t&&this.Ga.unshift(t);q.type=q.S.type||q.S.TYPE||"text/css";this.Kh(q);t&&this.write()};u.prototype.Kh=function(q){var t=this.fg(q);this.Mg(t);q.content&&(t.styleSheet&&!t.sheet?t.styleSheet.cssText=q.content:
t.appendChild(this.Qa.createTextNode(q.content)))};u.prototype.fg=function(q){var t=this.Qa.createElement(q.tagName);t.setAttribute("type",q.type);d(q.S,function(v,w){t.setAttribute(v,w)});return t};u.prototype.Mg=function(q){this.vd('<span id="ps-style"/>');var t=this.Qa.getElementById("ps-style");t.parentNode.replaceChild(q,t)};u.prototype.fd=function(q){q.dh=this.Ga;this.Ga=[];this.Ab.unshift(q)};u.prototype.Le=function(q){q!==this.Ab[0]?this.options.error({message:"Bad script nesting or script finished twice"}):
(this.Ab.shift(),this.write.apply(this,q.dh),!this.Ab.length&&this.Tb&&(this.fd(this.Tb),this.Tb=null))};u.prototype.Ih=function(q,t){var v=this.eg(q),w=this.xh(v),y=this.options.Qf;q.src&&(v.src=q.src,this.vh(v,w?y:function(){t();y()}));try{this.Lg(v),q.src&&!w||t()}catch(x){this.options.error(x),t()}};u.prototype.eg=function(q){var t=this.Qa.createElement(q.tagName);d(q.S,function(v,w){t.setAttribute(v,w)});q.content&&(t.text=q.content);return t};u.prototype.Lg=function(q){this.vd('<span id="ps-script"/>');
var t=this.Qa.getElementById("ps-script");t.parentNode.replaceChild(q,t)};u.prototype.vh=function(q,t){function v(){q=q.onload=q.onreadystatechange=q.onerror=null}var w=this.options.error;e(q,{onload:function(){v();t()},onreadystatechange:function(){/^(loaded|complete)$/.test(q.readyState)&&(v(),t())},onerror:function(){var y={message:"remote script failed "+q.src};v();w(y);t()}})};u.prototype.xh=function(q){return!/^script$/i.test(q.nodeName)||!!(this.options.rh&&q.src&&q.hasAttribute("async"))};
return u}();l.postscribe=function(){function r(){var w=t.shift(),y;w&&(y=w[w.length-1],y.Rf(),w.stream=u.apply(null,w),y.Sf())}function u(w,y,x){function A(H){H=x.bg(H);v.write(H);x.Tf(H)}v=new p(w,x);v.id=q++;v.name=x.name||v.id;var B=w.ownerDocument,z={close:B.close,open:B.open,write:B.write,writeln:B.writeln};e(B,{close:a,open:a,write:function(){return A(h(arguments).join(""))},writeln:function(){return A(h(arguments).join("")+"\n")}});var E=v.Eb.onerror||a;v.Eb.onerror=function(H,M,N){x.error({bi:H+
" - "+M+":"+N});E.apply(v.Eb,arguments)};v.write(y,function(){e(B,z);v.Eb.onerror=E;x.done();v=null;r()});return v}var q=0,t=[],v=null;return e(function(w,y,x){"function"===typeof x&&(x={done:x});x=f(x,k);w=/^#/.test(w)?l.document.getElementById(w.substr(1)):w.$h?w[0]:w;var A=[w,y,x];w.gh={cancel:function(){A.stream?A.stream.abort():A[1]=a}};x.ag(A);t.push(A);v||r();return w.gh},{streams:{},di:t,Sh:p})}();fc=l.postscribe}})();var C={wa:"_ee",Kc:"_syn",Rh:"_uei",Ac:"event_callback",Jb:"event_timeout",F:"gtag.config",da:"allow_ad_personalization_signals",Bc:"restricted_data_processing",$a:"allow_google_signals",fa:"cookie_expires",Ib:"cookie_update",ab:"session_duration",ka:"user_properties",va:"transport_url",M:"ads_data_redaction"};C.Ce=[C.da,C.$a,C.Ib];C.Fe=[C.fa,C.Jb,C.ab];var D=window,F=document,gc=navigator,hc=F.currentScript&&F.currentScript.src,ic=function(a,b){var c=D[a];D[a]=void 0===c?b:c;return D[a]},jc=function(a,b){b&&(a.addEventListener?a.onload=b:a.onreadystatechange=function(){a.readyState in{loaded:1,complete:1}&&(a.onreadystatechange=null,b())})},kc=function(a,b,c){var d=F.createElement("script");d.type="text/javascript";d.async=!0;d.src=a;jc(d,b);c&&(d.onerror=c);var e;if(null===na)b:{var f=ja.document,h=f.querySelector&&f.querySelector("script[nonce]");
if(h){var k=h.nonce||h.getAttribute("nonce");if(k&&la.test(k)){na=k;break b}}na=""}e=na;e&&d.setAttribute("nonce",e);var l=F.getElementsByTagName("script")[0]||F.body||F.head;l.parentNode.insertBefore(d,l);return d},lc=function(){if(hc){var a=hc.toLowerCase();if(0===a.indexOf("https://"))return 2;if(0===a.indexOf("http://"))return 3}return 1},mc=function(a,b){var c=F.createElement("iframe");c.height="0";c.width="0";c.style.display="none";c.style.visibility="hidden";var d=F.body&&F.body.lastChild||
F.body||F.head;d.parentNode.insertBefore(c,d);jc(c,b);void 0!==a&&(c.src=a);return c},nc=function(a,b,c){var d=new Image(1,1);d.onload=function(){d.onload=null;b&&b()};d.onerror=function(){d.onerror=null;c&&c()};d.src=a;return d},oc=function(a,b,c,d){a.addEventListener?a.addEventListener(b,c,!!d):a.attachEvent&&a.attachEvent("on"+b,c)},pc=function(a,b,c){a.removeEventListener?a.removeEventListener(b,c,!1):a.detachEvent&&a.detachEvent("on"+b,c)},G=function(a){D.setTimeout(a,0)},qc=function(a,b){return a&&
b&&a.attributes&&a.attributes[b]?a.attributes[b].value:null},rc=function(a){var b=a.innerText||a.textContent||"";b&&" "!=b&&(b=b.replace(/^[\s\xa0]+|[\s\xa0]+$/g,""));b&&(b=b.replace(/(\xa0+|\s{2,}|\n|\r\t)/g," "));return b},sc=function(a){var b=F.createElement("div");b.innerHTML="A<div>"+a+"</div>";b=b.lastChild;for(var c=[];b.firstChild;)c.push(b.removeChild(b.firstChild));return c},tc=function(a,b,c){c=c||100;for(var d={},e=0;e<b.length;e++)d[b[e]]=!0;for(var f=a,h=0;f&&h<=c;h++){if(d[String(f.tagName).toLowerCase()])return f;
f=f.parentElement}return null},uc=function(a){gc.sendBeacon&&gc.sendBeacon(a)||nc(a)},vc=function(a,b){var c=a[b];c&&"string"===typeof c.animVal&&(c=c.animVal);return c};var wc={},I=function(a,b){wc[a]=wc[a]||[];wc[a][b]=!0},xc=function(a){for(var b=[],c=wc[a]||[],d=0;d<c.length;d++)c[d]&&(b[Math.floor(d/6)]^=1<<d%6);for(var e=0;e<b.length;e++)b[e]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(b[e]||0);return b.join("")};var yc=[];function zc(){var a=ic("google_tag_data",{});a.ics||(a.ics={entries:{},set:Ac,update:Bc,addListener:Cc,notifyListeners:Dc,active:!1});return a.ics}
function Ac(a,b,c,d,e,f){var h=zc();h.active=!0;if(void 0!=b){var k=h.entries,l=k[a]||{},m=l.region,p=c&&g(c)?c.toUpperCase():void 0;d=d.toUpperCase();e=e.toUpperCase();if(p===e||(p===d?m!==e:!p&&!m)){var r=!!(f&&0<f&&void 0===l.update),u={region:p,initial:"granted"===b,update:l.update,quiet:r};k[a]=u;r&&D.setTimeout(function(){k[a]===u&&u.quiet&&(u.quiet=!1,Fc(a),Dc(),I("TAGGING",2))},f)}}}
function Bc(a,b){var c=zc();c.active=!0;if(void 0!=b){var d=Gc(a),e=c.entries,f=e[a]=e[a]||{};f.update="granted"===b;var h=Gc(a);f.quiet?(f.quiet=!1,Fc(a)):h!==d&&Fc(a)}}function Cc(a,b){yc.push({ne:a,Ag:b})}function Fc(a){for(var b=0;b<yc.length;++b){var c=yc[b];ra(c.ne)&&-1!==c.ne.indexOf(a)&&(c.Pe=!0)}}function Dc(){for(var a=0;a<yc.length;++a){var b=yc[a];if(b.Pe){b.Pe=!1;try{b.Ag.call()}catch(c){}}}}
var Gc=function(a){var b=zc().entries[a]||{};return void 0!==b.update?b.update:void 0!==b.initial?b.initial:void 0},Hc=function(a){return!(zc().entries[a]||{}).quiet},Ic=function(){return zc().active},Jc=function(a,b){zc().addListener(a,b)},Kc=function(a,b){function c(){for(var e=0;e<b.length;e++)if(!Hc(b[e]))return!0;return!1}if(c()){var d=!1;Jc(b,function(){d||c()||(d=!0,a())})}else a()},Lc=function(a,b){if(!1===Gc(b)){var c=!1;Jc([b],function(){!c&&Gc(b)&&(a(),c=!0)})}};var Mc=[C.o,C.J],Nc=function(a){var b=a[C.nh];b&&I("GTM",40);var c=a[C.uh];c&&I("GTM",41);for(var d=ra(b)?b:[b],e=0;e<d.length;++e)for(var f=0;f<Mc.length;f++){var h=Mc[f],k=a[Mc[f]],l=d[e];zc().set(h,k,l,"US","US-CT",c)}},Oc=function(a){for(var b=0;b<Mc.length;b++){var c=Mc[b],d=a[Mc[b]];zc().update(c,d)}zc().notifyListeners()},Pc=function(a){var b=Gc(a);return void 0!=b?b:!0},Qc=function(){for(var a=[],b=0;b<Mc.length;b++){var c=Gc(Mc[b]);a[b]=!0===c?"1":!1===c?"0":"-"}return"G1"+
a.join("")},Rc=function(a){Lc(a,C.o)},Sc=function(a,b){Kc(a,b)};var Uc=function(a){return Tc?F.querySelectorAll(a):null},Vc=function(a,b){if(!Tc)return null;if(Element.prototype.closest)try{return a.closest(b)}catch(e){return null}var c=Element.prototype.matches||Element.prototype.webkitMatchesSelector||Element.prototype.mozMatchesSelector||Element.prototype.msMatchesSelector||Element.prototype.oMatchesSelector,d=a;if(!F.documentElement.contains(d))return null;do{try{if(c.call(d,b))return d}catch(e){break}d=d.parentElement||d.parentNode}while(null!==d&&1===d.nodeType);
return null},Wc=!1;if(F.querySelectorAll)try{var Xc=F.querySelectorAll(":root");Xc&&1==Xc.length&&Xc[0]==F.documentElement&&(Wc=!0)}catch(a){}var Tc=Wc;var kd={},ld=null,md=Math.random();kd.s="GTM-K95SXT";kd.Ob="5e1";kd.Md="";var nd={__cl:!0,__ecl:!0,__ehl:!0,__evl:!0,__fal:!0,__fil:!0,__fsl:!0,__hl:!0,__jel:!0,__lcl:!0,__sdl:!0,__tl:!0,__ytl:!0,__paused:!0,__tg:!0},od="www.googletagmanager.com/gtm.js";
var qd=od,rd=null,sd=null,td=null,ud="//www.googletagmanager.com/a?id="+kd.s+"&cv=154",vd={},wd={},xd=function(){var a=ld.sequence||0;ld.sequence=a+1;return a};
var yd=function(){return"&tc="+ub.filter(function(a){return a}).length},Bd=function(){zd||(zd=D.setTimeout(Ad,500))},Ad=function(){zd&&(D.clearTimeout(zd),zd=void 0);void 0===Cd||Dd[Cd]&&!Ed&&!Fd||(Gd[Cd]||Hd.Rg()||0>=Id--?(I("GTM",1),Gd[Cd]=!0):(Hd.ph(),nc(Jd()),Dd[Cd]=!0,Kd=Ld=Fd=Ed=""))},Jd=function(){var a=Cd;if(void 0===a)return"";var b=xc("GTM"),c=xc("TAGGING");return[Md,Dd[a]?"":"&es=1",Nd[a],b?"&u="+b:"",c?"&ut="+c:"",yd(),Ed,Fd,Ld,Kd,"&z=0"].join("")},Od=function(){return[ud,"&v=3&t=t","&pid="+
wa(),"&rv="+kd.Ob].join("")},Pd="0.005000">Math.random(),Md=Od(),Qd=function(){Md=Od()},Dd={},Ed="",Fd="",Kd="",Ld="",Cd=void 0,Nd={},Gd={},zd=void 0,Hd=function(a,b){var c=0,d=0;return{Rg:function(){if(c<a)return!1;Fa()-d>=b&&(c=0);return c>=a},ph:function(){Fa()-d>=b&&(c=0);c++;d=Fa()}}}(2,1E3),Id=1E3,Rd=function(a,b){if(Pd&&!Gd[a]&&Cd!==a){Ad();Cd=a;Kd=Ed="";var c;c=0===b.indexOf("gtm.")?encodeURIComponent(b):"*";Nd[a]="&e="+c+"&eid="+a;Bd()}},Sd=function(a,b,c){if(Pd&&!Gd[a]&&
b){a!==Cd&&(Ad(),Cd=a);var d,e=String(b[Hb.ya]||"").replace(/_/g,"");0===e.indexOf("cvt")&&(e="cvt");d=e;var f=c+d;Ed=Ed?Ed+"."+f:"&tr="+f;var h=b["function"];if(!h)throw Error("Error: No function name given for function call.");var k=(wb[h]?"1":"2")+d;Kd=Kd?Kd+"."+k:"&ti="+k;Bd();2022<=Jd().length&&Ad()}},Td=function(a,b,c){if(Pd&&!Gd[a]){a!==Cd&&(Ad(),Cd=a);var d=c+b;Fd=Fd?Fd+
"."+d:"&epr="+d;Bd();2022<=Jd().length&&Ad()}};var Ud={},Vd=new xa,Wd={},Xd={},$d={name:"dataLayer",set:function(a,b){n(Ma(a,b),Wd);Yd()},get:function(a){return Zd(a,2)},reset:function(){Vd=new xa;Wd={};Yd()}},Zd=function(a,b){if(2!=b){var c=Vd.get(a);if(Pd){var d=ae(a);c!==d&&I("GTM",5)}return c}return ae(a)},ae=function(a){var b=a.split("."),c=!1,d=void 0;return c?d:be(b)},be=function(a){for(var b=Wd,c=0;c<a.length;c++){if(null===b)return!1;if(void 0===b)break;b=b[a[c]]}return b};
var ce=function(a,b){Xd.hasOwnProperty(a)||(Vd.set(a,b),n(Ma(a,b),Wd),Yd())},Yd=function(a){za(Xd,function(b,c){Vd.set(b,c);n(Ma(b,void 0),Wd);n(Ma(b,c),Wd);a&&delete Xd[b]})},de=function(a,b,c){Ud[a]=Ud[a]||{};var d=1!==c?ae(b):Vd.get(b);"array"===Pa(d)||"object"===Pa(d)?Ud[a][b]=n(d):Ud[a][b]=d},ee=function(a,b){if(Ud[a])return Ud[a][b]},fe=function(a,b){Ud[a]&&delete Ud[a][b]};var ie=/^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;var je=/:[0-9]+$/,ke=function(a,b,c){for(var d=a.split("&"),e=0;e<d.length;e++){var f=d[e].split("=");if(decodeURIComponent(f[0]).replace(/\+/g," ")===b){var h=f.slice(1).join("=");return c?h:decodeURIComponent(h).replace(/\+/g," ")}}},ne=function(a,b,c,d,e){b&&(b=String(b).toLowerCase());if("protocol"===b||"port"===b)a.protocol=le(a.protocol)||le(D.location.protocol);"port"===b?a.port=String(Number(a.hostname?a.port:D.location.port)||("http"==a.protocol?80:"https"==a.protocol?443:"")):"host"===b&&
(a.hostname=(a.hostname||D.location.hostname).replace(je,"").toLowerCase());return me(a,b,c,d,e)},me=function(a,b,c,d,e){var f,h=le(a.protocol);b&&(b=String(b).toLowerCase());switch(b){case "url_no_fragment":f=oe(a);break;case "protocol":f=h;break;case "host":f=a.hostname.replace(je,"").toLowerCase();if(c){var k=/^www\d*\./.exec(f);k&&k[0]&&(f=f.substr(k[0].length))}break;case "port":f=String(Number(a.port)||("http"==h?80:"https"==h?443:""));break;case "path":a.pathname||a.hostname||I("TAGGING",1);
f="/"==a.pathname.substr(0,1)?a.pathname:"/"+a.pathname;var l=f.split("/");0<=ta(d||[],l[l.length-1])&&(l[l.length-1]="");f=l.join("/");break;case "query":f=a.search.replace("?","");e&&(f=ke(f,e,void 0));break;case "extension":var m=a.pathname.split(".");f=1<m.length?m[m.length-1]:"";f=f.split("/")[0];break;case "fragment":f=a.hash.replace("#","");break;default:f=a&&a.href}return f},le=function(a){return a?a.replace(":","").toLowerCase():""},oe=function(a){var b="";if(a&&a.href){var c=a.href.indexOf("#");
b=0>c?a.href:a.href.substr(0,c)}return b},pe=function(a){var b=F.createElement("a");a&&(b.href=a);var c=b.pathname;"/"!==c[0]&&(a||I("TAGGING",1),c="/"+c);var d=b.hostname.replace(je,"");return{href:b.href,protocol:b.protocol,host:b.host,hostname:d,pathname:c,search:b.search,hash:b.hash,port:b.port}},qe=function(a){function b(m){var p=m.split("=")[0];return 0>d.indexOf(p)?m:p+"=0"}function c(m){return m.split("&").map(b).filter(function(p){return void 0!=p}).join("&")}var d="gclid dclid gclaw gcldc gclgp gclha gclgf _gl".split(" "),
e=pe(a),f=a.split(/[?#]/)[0],h=e.search,k=e.hash;"?"===h[0]&&(h=h.substring(1));"#"===k[0]&&(k=k.substring(1));h=c(h);k=c(k);""!==h&&(h="?"+h);""!==k&&(k="#"+k);var l=""+f+h+k;"/"===l[l.length-1]&&(l=l.substring(0,l.length-1));return l};function re(a,b,c){for(var d=[],e=b.split(";"),f=0;f<e.length;f++){var h=e[f].split("="),k=h[0].replace(/^\s*|\s*$/g,"");if(k&&k==a){var l=h.slice(1).join("=").replace(/^\s*|\s*$/g,"");l&&c&&(l=decodeURIComponent(l));d.push(l)}}return d};var se={},te=function(a){return void 0==se[a]?!1:se[a]};var ve=function(a,b,c,d){return ue(d)?re(a,String(b||document.cookie),c):[]},ye=function(a,b,c,d,e){if(ue(e)){var f=we(a,d,e);if(1===f.length)return f[0].id;if(0!==f.length){f=xe(f,function(h){return h.Ub},b);if(1===f.length)return f[0].id;f=xe(f,function(h){return h.yb},c);return f[0]?f[0].id:void 0}}};function ze(a,b,c,d){var e=document.cookie;document.cookie=a;var f=document.cookie;return e!=f||void 0!=c&&0<=ve(b,f,!1,d).indexOf(c)}
var De=function(a,b,c){function d(q,t,v){if(null==v)return delete h[t],q;h[t]=v;return q+"; "+t+"="+v}function e(q,t){if(null==t)return delete h[t],q;h[t]=!0;return q+"; "+t}if(!ue(c.Da))return 2;var f;void 0==b?f=a+"=deleted; expires="+(new Date(0)).toUTCString():(c.encode&&(b=encodeURIComponent(b)),b=Ae(b),f=a+"="+b);var h={};f=d(f,"path",c.path);var k;c.expires instanceof Date?k=c.expires.toUTCString():null!=c.expires&&(k=""+c.expires);f=d(f,"expires",k);f=d(f,"max-age",c.ai);f=d(f,"samesite",
c.gi);c.hi&&(f=e(f,"secure"));f=e(f,c.flags);var l=c.domain;if("auto"===l){for(var m=Be(),p=0;p<m.length;++p){var r="none"!==m[p]?m[p]:void 0,u=d(f,"domain",r);if(!Ce(r,c.path)&&ze(u,a,b,c.Da))return 0}return 1}l&&"none"!==l&&(f=d(f,"domain",l));return Ce(l,c.path)?1:ze(f,a,b,c.Da)?0:1},Ee=function(a,b,c){null==c.path&&(c.path="/");c.domain||(c.domain="auto");return De(a,b,c)};
function xe(a,b,c){for(var d=[],e=[],f,h=0;h<a.length;h++){var k=a[h],l=b(k);l===c?d.push(k):void 0===f||l<f?(e=[k],f=l):l===f&&e.push(k)}return 0<d.length?d:e}function we(a,b,c){for(var d=[],e=ve(a,void 0,void 0,c),f=0;f<e.length;f++){var h=e[f].split("."),k=h.shift();if(!b||-1!==b.indexOf(k)){var l=h.shift();l&&(l=l.split("-"),d.push({id:h.join("."),Ub:1*l[0]||1,yb:1*l[1]||1}))}}return d}
var Ae=function(a){a&&1200<a.length&&(a=a.substring(0,1200));return a},Fe=/^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,Ge=/(^|\.)doubleclick\.net$/i,Ce=function(a,b){return Ge.test(document.location.hostname)||"/"===b&&Fe.test(a)},Be=function(){var a=[],b=document.location.hostname.split(".");if(4===b.length){var c=b[b.length-1];if(parseInt(c,10).toString()===c)return["none"]}for(var d=b.length-2;0<=d;d--)a.push(b.slice(d).join("."));var e=document.location.hostname;Ge.test(e)||Fe.test(e)||a.push("none");
return a},ue=function(a){if(!te("gtag_cs_api")||!a||!Ic())return!0;if(!Hc(a))return!1;var b=Gc(a);return null==b?!0:!!b};var He=function(){for(var a=gc.userAgent+(F.cookie||"")+(F.referrer||""),b=a.length,c=D.history.length;0<c;)a+=c--^b++;var d=1,e,f,h;if(a)for(d=0,f=a.length-1;0<=f;f--)h=a.charCodeAt(f),d=(d<<6&268435455)+h+(h<<14),e=d&266338304,d=0!=e?d^e>>21:d;return[Math.round(2147483647*Math.random())^d&2147483647,Math.round(Fa()/1E3)].join(".")},Ke=function(a,b,c,d,e){var f=Ie(b);return ye(a,f,Je(c),d,e)},Le=function(a,b,c,d){var e=""+Ie(c),f=Je(d);1<f&&(e+="-"+f);return[b,e,a].join(".")},Ie=function(a){if(!a)return 1;
a=0===a.indexOf(".")?a.substr(1):a;return a.split(".").length},Je=function(a){if(!a||"/"===a)return 1;"/"!==a[0]&&(a="/"+a);"/"!==a[a.length-1]&&(a+="/");return a.split("/").length-1};function Me(a,b,c){var d,e=a.wb;null==e&&(e=7776E3);0!==e&&(d=new Date((b||Fa())+1E3*e));return{path:a.path,domain:a.domain,flags:a.flags,encode:!!c,expires:d}};var Ne=["1"],Oe={},Se=function(a){var b=Pe(a.prefix);Oe[b]||Qe(b,a.path,a.domain)||(Re(b,He(),a),Qe(b,a.path,a.domain))};function Re(a,b,c){var d=Le(b,"1",c.domain,c.path),e=Me(c);e.Da="ad_storage";Ee(a,d,e)}function Qe(a,b,c){var d=Ke(a,b,c,Ne,"ad_storage");d&&(Oe[a]=d);return d}function Pe(a){return(a||"_gcl")+"_au"};function Te(){for(var a=Ue,b={},c=0;c<a.length;++c)b[a[c]]=c;return b}function Ve(){var a="ABCDEFGHIJKLMNOPQRSTUVWXYZ";a+=a.toLowerCase()+"0123456789-_";return a+"."}var Ue,We;function Xe(a){Ue=Ue||Ve();We=We||Te();for(var b=[],c=0;c<a.length;c+=3){var d=c+1<a.length,e=c+2<a.length,f=a.charCodeAt(c),h=d?a.charCodeAt(c+1):0,k=e?a.charCodeAt(c+2):0,l=f>>2,m=(f&3)<<4|h>>4,p=(h&15)<<2|k>>6,r=k&63;e||(r=64,d||(p=64));b.push(Ue[l],Ue[m],Ue[p],Ue[r])}return b.join("")}
function Ye(a){function b(l){for(;d<a.length;){var m=a.charAt(d++),p=We[m];if(null!=p)return p;if(!/^[\s\xa0]*$/.test(m))throw Error("Unknown base64 encoding at char: "+m);}return l}Ue=Ue||Ve();We=We||Te();for(var c="",d=0;;){var e=b(-1),f=b(0),h=b(64),k=b(64);if(64===k&&-1===e)return c;c+=String.fromCharCode(e<<2|f>>4);64!=h&&(c+=String.fromCharCode(f<<4&240|h>>2),64!=k&&(c+=String.fromCharCode(h<<6&192|k)))}};var Ze;var cf=function(){var a=$e,b=af,c=bf(),d=function(h){a(h.target||h.srcElement||{})},e=function(h){b(h.target||h.srcElement||{})};if(!c.init){oc(F,"mousedown",d);oc(F,"keyup",d);oc(F,"submit",e);var f=HTMLFormElement.prototype.submit;HTMLFormElement.prototype.submit=function(){b(this);f.call(this)};c.init=!0}},df=function(a,b,c,d,e){var f={callback:a,domains:b,fragment:2===c,placement:c,forms:d,sameHost:e};bf().decorators.push(f)},ef=function(a,b,c){for(var d=bf().decorators,e={},f=0;f<d.length;++f){var h=
d[f],k;if(k=!c||h.forms)a:{var l=h.domains,m=a;if(l&&(h.sameHost||m!==F.location.hostname))for(var p=0;p<l.length;p++)if(l[p]instanceof RegExp){if(l[p].test(m)){k=!0;break a}}else if(0<=m.indexOf(l[p])){k=!0;break a}k=!1}if(k){var r=h.placement;void 0==r&&(r=h.fragment?2:1);r===b&&Ia(e,h.callback())}}return e},bf=function(){var a=ic("google_tag_data",{}),b=a.gl;b&&b.decorators||(b={decorators:[]},a.gl=b);return b};var ff=/(.*?)\*(.*?)\*(.*)/,gf=/^https?:\/\/([^\/]*?)\.?cdn\.ampproject\.org\/?(.*)/,hf=/^(?:www\.|m\.|amp\.)+/,jf=/([^?#]+)(\?[^#]*)?(#.*)?/;function kf(a){return new RegExp("(.*?)(^|&)"+a+"=([^&]*)&?(.*)")}
var mf=function(a){var b=[],c;for(c in a)if(a.hasOwnProperty(c)){var d=a[c];void 0!==d&&d===d&&null!==d&&"[object Object]"!==d.toString()&&(b.push(c),b.push(Xe(String(d))))}var e=b.join("*");return["1",lf(e),e].join("*")},lf=function(a,b){var c=[window.navigator.userAgent,(new Date).getTimezoneOffset(),window.navigator.userLanguage||window.navigator.language,Math.floor((new Date).getTime()/60/1E3)-(void 0===b?0:b),a].join("*"),d;if(!(d=Ze)){for(var e=Array(256),f=0;256>f;f++){for(var h=f,k=0;8>k;k++)h=
h&1?h>>>1^3988292384:h>>>1;e[f]=h}d=e}Ze=d;for(var l=4294967295,m=0;m<c.length;m++)l=l>>>8^Ze[(l^c.charCodeAt(m))&255];return((l^-1)>>>0).toString(36)},of=function(){return function(a){var b=pe(D.location.href),c=b.search.replace("?",""),d=ke(c,"_gl",!0)||"";a.query=nf(d)||{};var e=ne(b,"fragment").match(kf("_gl"));a.fragment=nf(e&&e[3]||"")||{}}},pf=function(a){var b=of(),c=bf();c.data||(c.data={query:{},fragment:{}},b(c.data));var d={},e=c.data;e&&(Ia(d,e.query),a&&Ia(d,e.fragment));return d},nf=
function(a){var b;b=void 0===b?3:b;try{if(a){var c;a:{for(var d=a,e=0;3>e;++e){var f=ff.exec(d);if(f){c=f;break a}d=decodeURIComponent(d)}c=void 0}var h=c;if(h&&"1"===h[1]){var k=h[3],l;a:{for(var m=h[2],p=0;p<b;++p)if(m===lf(k,p)){l=!0;break a}l=!1}if(l){for(var r={},u=k?k.split("*"):[],q=0;q<u.length;q+=2)r[u[q]]=Ye(u[q+1]);return r}}}}catch(t){}};
function qf(a,b,c,d){function e(p){var r=p,u=kf(a).exec(r),q=r;if(u){var t=u[2],v=u[4];q=u[1];v&&(q=q+t+v)}p=q;var w=p.charAt(p.length-1);p&&"&"!==w&&(p+="&");return p+m}d=void 0===d?!1:d;var f=jf.exec(c);if(!f)return"";var h=f[1],k=f[2]||"",l=f[3]||"",m=a+"="+b;d?l="#"+e(l.substring(1)):k="?"+e(k.substring(1));return""+h+k+l}
function rf(a,b){var c="FORM"===(a.tagName||"").toUpperCase(),d=ef(b,1,c),e=ef(b,2,c),f=ef(b,3,c);if(Ja(d)){var h=mf(d);c?sf("_gl",h,a):tf("_gl",h,a,!1)}if(!c&&Ja(e)){var k=mf(e);tf("_gl",k,a,!0)}for(var l in f)if(f.hasOwnProperty(l))a:{var m=l,p=f[l],r=a;if(r.tagName){if("a"===r.tagName.toLowerCase()){tf(m,p,r,void 0);break a}if("form"===r.tagName.toLowerCase()){sf(m,p,r);break a}}"string"==typeof r&&qf(m,p,r,void 0)}}
function tf(a,b,c,d){if(c.href){var e=qf(a,b,c.href,void 0===d?!1:d);ie.test(e)&&(c.href=e)}}
function sf(a,b,c){if(c&&c.action){var d=(c.method||"").toLowerCase();if("get"===d){for(var e=c.childNodes||[],f=!1,h=0;h<e.length;h++){var k=e[h];if(k.name===a){k.setAttribute("value",b);f=!0;break}}if(!f){var l=F.createElement("input");l.setAttribute("type","hidden");l.setAttribute("name",a);l.setAttribute("value",b);c.appendChild(l)}}else if("post"===d){var m=qf(a,b,c.action);ie.test(m)&&(c.action=m)}}}
var $e=function(a){try{var b;a:{for(var c=a,d=100;c&&0<d;){if(c.href&&c.nodeName.match(/^a(?:rea)?$/i)){b=c;break a}c=c.parentNode;d--}b=null}var e=b;if(e){var f=e.protocol;"http:"!==f&&"https:"!==f||rf(e,e.hostname)}}catch(h){}},af=function(a){try{if(a.action){var b=ne(pe(a.action),"host");rf(a,b)}}catch(c){}},uf=function(a,b,c,d){cf();df(a,b,"fragment"===c?2:1,!!d,!1)},vf=function(a,b){cf();df(a,[me(D.location,"host",!0)],b,!0,!0)},wf=function(){var a=F.location.hostname,b=gf.exec(F.referrer);if(!b)return!1;
var c=b[2],d=b[1],e="";if(c){var f=c.split("/"),h=f[1];e="s"===h?decodeURIComponent(f[2]):decodeURIComponent(h)}else if(d){if(0===d.indexOf("xn--"))return!1;e=d.replace(/-/g,".").replace(/\.\./g,"-")}var k=a.replace(hf,""),l=e.replace(hf,""),m;if(!(m=k===l)){var p="."+l;m=k.substring(k.length-p.length,k.length)===p}return m},xf=function(a,b){return!1===a?!1:a||b||wf()};var yf=/^\w+$/,zf=/^[\w-]+$/,Af=/^~?[\w-]+$/,Bf={aw:"_aw",dc:"_dc",gf:"_gf",ha:"_ha",gp:"_gp"},Cf=function(){if(!te("gtag_cs_api")||!Ic())return!0;var a=Gc("ad_storage");return null==a?!0:!!a},Df=function(a,b){Hc("ad_storage")?Cf()?a():Lc(a,"ad_storage"):b?I("TAGGING",3):Kc(function(){Df(a,!0)},["ad_storage"])},Gf=function(a){var b=[];if(!F.cookie)return b;var c=ve(a,F.cookie,void 0,"ad_storage");if(!c||0==c.length)return b;for(var d=0;d<c.length;d++){var e=Ef(c[d]);e&&-1===ta(b,e)&&b.push(e)}return Ff(b)};
function Hf(a){return a&&"string"==typeof a&&a.match(yf)?a:"_gcl"}
var Jf=function(){var a=pe(D.location.href),b=ne(a,"query",!1,void 0,"gclid"),c=ne(a,"query",!1,void 0,"gclsrc"),d=ne(a,"query",!1,void 0,"dclid");if(!b||!c){var e=a.hash.replace("#","");b=b||ke(e,"gclid",void 0);c=c||ke(e,"gclsrc",void 0)}return If(b,c,d)},If=function(a,b,c){var d={},e=function(f,h){d[h]||(d[h]=[]);d[h].push(f)};d.gclid=a;d.gclsrc=b;d.dclid=c;if(void 0!==a&&a.match(zf))switch(b){case void 0:e(a,"aw");break;case "aw.ds":e(a,"aw");e(a,"dc");break;case "ds":e(a,"dc");break;case "3p.ds":te("gtm_3pds")&&
e(a,"dc");break;case "gf":e(a,"gf");break;case "ha":e(a,"ha");break;case "gp":e(a,"gp")}c&&e(c,"dc");return d},Lf=function(a){var b=Jf();Df(function(){return Kf(b,a)})};
function Kf(a,b,c){function d(m,p){var r=Mf(m,e);r&&(Ee(r,p,f),h=!0)}b=b||{};var e=Hf(b.prefix);c=c||Fa();var f=Me(b,c,!0);f.Da="ad_storage";var h=!1,k=Math.round(c/1E3),l=function(m){return["GCL",k,m].join(".")};a.aw&&(!0===b.li?d("aw",l("~"+a.aw[0])):d("aw",l(a.aw[0])));a.dc&&d("dc",l(a.dc[0]));a.gf&&d("gf",l(a.gf[0]));a.ha&&d("ha",l(a.ha[0]));a.gp&&d("gp",l(a.gp[0]));return h}
var Of=function(a,b){var c=pf(!0);Df(function(){for(var d=Hf(b.prefix),e=0;e<a.length;++e){var f=a[e];if(void 0!==Bf[f]){var h=Mf(f,d),k=c[h];if(k){var l=Math.min(Nf(k),Fa()),m;b:{for(var p=l,r=ve(h,F.cookie,void 0,"ad_storage"),u=0;u<r.length;++u)if(Nf(r[u])>p){m=!0;break b}m=!1}if(!m){var q=Me(b,l,!0);q.Da="ad_storage";Ee(h,k,q)}}}}Kf(If(c.gclid,c.gclsrc),b)})},Mf=function(a,b){var c=Bf[a];if(void 0!==c)return b+c},Nf=function(a){var b=a.split(".");return 3!==b.length||"GCL"!==b[0]?0:1E3*(Number(b[1])||
0)};function Ef(a){var b=a.split(".");if(3==b.length&&"GCL"==b[0]&&b[1])return b[2]}
var Pf=function(a,b,c,d,e){if(ra(b)){var f=Hf(e),h=function(){for(var k={},l=0;l<a.length;++l){var m=Mf(a[l],f);if(m){var p=ve(m,F.cookie,void 0,"ad_storage");p.length&&(k[m]=p.sort()[p.length-1])}}return k};Df(function(){uf(h,b,c,d)})}},Ff=function(a){return a.filter(function(b){return Af.test(b)})},Qf=function(a,b){for(var c=Hf(b.prefix),d={},e=0;e<a.length;e++)Bf[a[e]]&&(d[a[e]]=Bf[a[e]]);Df(function(){za(d,function(f,h){var k=ve(c+h,F.cookie,void 0,"ad_storage");if(k.length){var l=k[0],m=Nf(l),
p={};p[f]=[Ef(l)];Kf(p,b,m)}})})};function Rf(a,b){for(var c=0;c<b.length;++c)if(a[b[c]])return!0;return!1}
var Sf=function(){function a(e,f,h){h&&(e[f]=h)}var b=["aw","dc"];if(Ic()){var c=Jf();if(Rf(c,b)){var d={};a(d,"gclid",c.gclid);a(d,"dclid",c.dclid);a(d,"gclsrc",c.gclsrc);vf(function(){return d},3);vf(function(){var e={};return e._up="1",e},1)}}},Tf=function(){var a;if(Cf()){for(var b=[],c=F.cookie.split(";"),d=/^\s*_gac_(UA-\d+-\d+)=\s*(.+?)\s*$/,e=0;e<c.length;e++){var f=c[e].match(d);f&&b.push({rd:f[1],value:f[2]})}var h={};if(b&&b.length)for(var k=0;k<b.length;k++){var l=b[k].value.split(".");
"1"==l[0]&&3==l.length&&l[1]&&(h[b[k].rd]||(h[b[k].rd]=[]),h[b[k].rd].push({timestamp:l[1],Cg:l[2]}))}a=h}else a={};return a};var Uf=/^\d+\.fls\.doubleclick\.net$/;function Vf(a,b){Hc(C.o)?Pc(C.o)?a():Rc(a):b?I("GTM",42):Sc(function(){Vf(a,!0)},[C.o])}function Wf(a){var b=pe(D.location.href),c=ne(b,"host",!1);if(c&&c.match(Uf)){var d=ne(b,"path").split(a+"=");if(1<d.length)return d[1].split(";")[0].split("?")[0]}}
function Xf(a,b,c){if("aw"==a||"dc"==a){var d=Wf("gcl"+a);if(d)return d.split(".")}var e=Hf(b);if("_gcl"==e){c=void 0===c?!0:c;var f=!Pc(C.o)&&c,h;h=Jf()[a]||[];if(0<h.length)return f?["0"]:h}var k=Mf(a,e);return k?Gf(k):[]}
var Yf=function(a){var b=Wf("gac");if(b)return!Pc(C.o)&&a?"0":decodeURIComponent(b);var c=Tf(),d=[];za(c,function(e,f){for(var h=[],k=0;k<f.length;k++)h.push(f[k].Cg);h=Ff(h);h.length&&d.push(e+":"+h.join(","))});return d.join(";")},Zf=function(a,b){var c=Jf().dc||[];Vf(function(){Se(b);var d=Oe[Pe(b.prefix)],e=!1;if(d&&0<c.length){var f=ld.joined_au=ld.joined_au||{},h=b.prefix||"_gcl";if(!f[h])for(var k=0;k<c.length;k++){var l="https://adservice.google.com/ddm/regclk";l=l+"?gclid="+c[k]+"&auiddc="+d;uc(l);e=f[h]=
!0}}null==a&&(a=e);if(a&&d){var m=Pe(b.prefix),p=Oe[m];p&&Re(m,p,b)}})};var $f=/[A-Z]+/,ag=/\s/,bg=function(a){if(g(a)&&(a=Da(a),!ag.test(a))){var b=a.indexOf("-");if(!(0>b)){var c=a.substring(0,b);if($f.test(c)){for(var d=a.substring(b+1).split("/"),e=0;e<d.length;e++)if(!d[e])return;return{id:a,prefix:c,containerId:c+"-"+d[0],w:d}}}}},dg=function(a){for(var b={},c=0;c<a.length;++c){var d=bg(a[c]);d&&(b[d.id]=d)}cg(b);var e=[];za(b,function(f,h){e.push(h)});return e};
function cg(a){var b=[],c;for(c in a)if(a.hasOwnProperty(c)){var d=a[c];"AW"===d.prefix&&d.w[1]&&b.push(d.containerId)}for(var e=0;e<b.length;++e)delete a[b[e]]};var eg=function(){var a=!1;return a};var K=function(a,b,c,d){return(2===fg()||d||"http:"!=D.location.protocol?a:b)+c},fg=function(){var a=lc(),b;if(1===a)a:{var c=qd;c=c.toLowerCase();for(var d="https://"+c,e="http://"+c,f=1,h=F.getElementsByTagName("script"),k=0;k<h.length&&100>k;k++){var l=h[k].src;if(l){l=l.toLowerCase();if(0===l.indexOf(e)){b=3;break a}1===f&&0===l.indexOf(d)&&(f=2)}}b=f}else b=a;return b};
var tg=function(a){return Pc(C.o)?a:a.replace(/&url=([^&#]+)/,function(b,c){var d=qe(decodeURIComponent(c));return"&url="+encodeURIComponent(d)})};var ug=new RegExp(/^(.*\.)?(google|youtube|blogger|withgoogle)(\.com?)?(\.[a-z]{2})?\.?$/),vg={cl:["ecl"],customPixels:["nonGooglePixels"],ecl:["cl"],ehl:["hl"],hl:["ehl"],html:["customScripts","customPixels","nonGooglePixels","nonGoogleScripts","nonGoogleIframes"],customScripts:["html","customPixels","nonGooglePixels","nonGoogleScripts","nonGoogleIframes"],nonGooglePixels:[],nonGoogleScripts:["nonGooglePixels"],nonGoogleIframes:["nonGooglePixels"]},wg={cl:["ecl"],customPixels:["customScripts","html"],
ecl:["cl"],ehl:["hl"],hl:["ehl"],html:["customScripts"],customScripts:["html"],nonGooglePixels:["customPixels","customScripts","html","nonGoogleScripts","nonGoogleIframes"],nonGoogleScripts:["customScripts","html"],nonGoogleIframes:["customScripts","html","nonGoogleScripts"]},xg="google customPixels customScripts html nonGooglePixels nonGoogleScripts nonGoogleIframes".split(" ");
var zg=function(a){var b=Zd("gtm.whitelist");b&&I("GTM",9);var c=b&&Ka(Ca(b),vg),d=Zd("gtm.blacklist");d||(d=Zd("tagTypeBlacklist"))&&I("GTM",3);d?
I("GTM",8):d=[];yg()&&(d=Ca(d),d.push("nonGooglePixels","nonGoogleScripts","sandboxedScripts"));0<=ta(Ca(d),"google")&&I("GTM",2);var e=d&&Ka(Ca(d),wg),f={};return function(h){var k=h&&h[Hb.ya];if(!k||"string"!=typeof k)return!0;k=k.replace(/^_*/,"");if(void 0!==f[k])return f[k];var l=wd[k]||[],m=a(k,l);if(b){var p;if(p=m)a:{if(0>ta(c,k))if(l&&0<l.length)for(var r=
0;r<l.length;r++){if(0>ta(c,l[r])){I("GTM",11);p=!1;break a}}else{p=!1;break a}p=!0}m=p}var u=!1;if(d){var q=0<=ta(e,k);if(q)u=q;else{var t=ya(e,l||[]);t&&I("GTM",10);u=t}}var v=!m||u;v||!(0<=ta(l,"sandboxedScripts"))||c&&-1!==ta(c,"sandboxedScripts")||(v=ya(e,xg));return f[k]=v}},yg=function(){return ug.test(D.location&&D.location.hostname)};var Bg={mg:function(a,b){b[Hb.Cd]&&"string"===typeof a&&(a=1==b[Hb.Cd]?a.toLowerCase():a.toUpperCase());b.hasOwnProperty(Hb.Ed)&&null===a&&(a=b[Hb.Ed]);b.hasOwnProperty(Hb.Gd)&&void 0===a&&(a=b[Hb.Gd]);b.hasOwnProperty(Hb.Fd)&&!0===a&&(a=b[Hb.Fd]);b.hasOwnProperty(Hb.Dd)&&!1===a&&(a=b[Hb.Dd]);return a}};var Cg={active:!0,isWhitelisted:function(){return!0}},Dg=function(a){var b=ld.zones;!b&&a&&(b=ld.zones=a());return b};var Eg=function(){};var Fg=!1,Gg=0,Hg=[];function Ig(a){if(!Fg){var b=F.createEventObject,c="complete"==F.readyState,d="interactive"==F.readyState;if(!a||"readystatechange"!=a.type||c||!b&&d){Fg=!0;for(var e=0;e<Hg.length;e++)G(Hg[e])}Hg.push=function(){for(var f=0;f<arguments.length;f++)G(arguments[f]);return 0}}}function Jg(){if(!Fg&&140>Gg){Gg++;try{F.documentElement.doScroll("left"),Ig()}catch(a){D.setTimeout(Jg,50)}}}var Kg=function(a){Fg?a():Hg.push(a)};var Lg={},Mg={},Ng=function(a,b,c,d){if(!Mg[a]||nd[b]||"__zone"===b)return-1;var e={};Sa(d)&&(e=n(d,e));e.id=c;e.status="timeout";return Mg[a].tags.push(e)-1},Og=function(a,b,c,d){if(Mg[a]){var e=Mg[a].tags[b];e&&(e.status=c,e.executionTime=d)}};function Pg(a){for(var b=Lg[a]||[],c=0;c<b.length;c++)b[c]();Lg[a]={push:function(d){d(kd.s,Mg[a])}}}
var Sg=function(a,b,c){Mg[a]={tags:[]};pa(b)&&Qg(a,b);c&&D.setTimeout(function(){return Pg(a)},Number(c));return Rg(a)},Qg=function(a,b){Lg[a]=Lg[a]||[];Lg[a].push(Ha(function(){return G(function(){b(kd.s,Mg[a])})}))};function Rg(a){var b=0,c=0,d=!1;return{add:function(){c++;return Ha(function(){b++;d&&b>=c&&Pg(a)})},Yf:function(){d=!0;b>=c&&Pg(a)}}};var Tg=function(){function a(d){return!qa(d)||0>d?0:d}if(!ld._li&&D.performance&&D.performance.timing){var b=D.performance.timing.navigationStart,c=qa($d.get("gtm.start"))?$d.get("gtm.start"):0;ld._li={cst:a(c-b),cbt:a(sd-b)}}};var Xg={},Yg=function(){return D.GoogleAnalyticsObject&&D[D.GoogleAnalyticsObject]},Zg=!1;
var $g=function(a){D.GoogleAnalyticsObject||(D.GoogleAnalyticsObject=a||"ga");var b=D.GoogleAnalyticsObject;if(D[b])D.hasOwnProperty(b)||I("GTM",12);else{var c=function(){c.q=c.q||[];c.q.push(arguments)};c.l=Number(new Date);D[b]=c}Tg();return D[b]},ah=function(a,b,c,d){b=String(b).replace(/\s+/g,"").split(",");var e=Yg();e(a+"require","linker");e(a+"linker:autoLink",b,c,d)};
var ch=function(a){},bh=function(){return D.GoogleAnalyticsObject||"ga"};function ih(a,b,c,d){var e=ub[a],f=jh(a,b,c,d);if(!f)return null;var h=Db(e[Hb.Vd],c,[]);if(h&&h.length){var k=h[0];f=ih(k.index,{C:f,B:1===k.te?b.terminate:f,terminate:b.terminate},c,d)}return f}
function jh(a,b,c,d){function e(){if(f[Hb.sf])k();else{var w=Eb(f,c,[]),y=Ng(c.id,String(f[Hb.ya]),Number(f[Hb.Xd]),w[Hb.tf]),x=!1;w.vtp_gtmOnSuccess=function(){if(!x){x=!0;var z=Fa()-B;Sd(c.id,ub[a],"5");Og(c.id,y,"success",z);h()}};w.vtp_gtmOnFailure=function(){if(!x){x=!0;var z=Fa()-B;Sd(c.id,ub[a],"6");Og(c.id,y,"failure",z);k()}};w.vtp_gtmTagId=f.tag_id;
w.vtp_gtmEventId=c.id;Sd(c.id,f,"1");var A=function(){var z=Fa()-B;Sd(c.id,f,"7");Og(c.id,y,"exception",z);x||(x=!0,k())};var B=Fa();try{Bb(w,c)}catch(z){A(z)}}}var f=ub[a],h=b.C,k=b.B,l=b.terminate;if(c.Yc(f))return null;var m=Db(f[Hb.Yd],c,[]);if(m&&m.length){var p=m[0],r=ih(p.index,{C:h,B:k,terminate:l},c,d);if(!r)return null;h=r;k=2===p.te?l:r}if(f[Hb.Nd]||f[Hb.xf]){var u=f[Hb.Nd]?vb:c.yh,q=h,t=k;if(!u[a]){e=Ha(e);var v=kh(a,u,e);h=v.C;k=v.B}return function(){u[a](q,t)}}return e}
function kh(a,b,c){var d=[],e=[];b[a]=lh(d,e,c);return{C:function(){b[a]=mh;for(var f=0;f<d.length;f++)d[f]()},B:function(){b[a]=nh;for(var f=0;f<e.length;f++)e[f]()}}}function lh(a,b,c){return function(d,e){a.push(d);b.push(e);c()}}function mh(a){a()}function nh(a,b){b()};var qh=function(a,b){for(var c=[],d=0;d<ub.length;d++)if(a.xb[d]){var e=ub[d];var f=b.add();try{var h=ih(d,{C:f,B:f,terminate:f},a,d);h?c.push({We:d,Qe:Fb(e),yg:h}):(oh(d,a),f())}catch(l){f()}}b.Yf();c.sort(ph);for(var k=0;k<c.length;k++)c[k].yg();return 0<c.length};function ph(a,b){var c,d=b.Qe,e=a.Qe;c=d>e?1:d<e?-1:0;var f;if(0!==c)f=c;else{var h=a.We,k=b.We;f=h>k?1:h<k?-1:0}return f}
function oh(a,b){if(!Pd)return;var c=function(d){var e=b.Yc(ub[d])?"3":"4",f=Db(ub[d][Hb.Vd],b,[]);f&&f.length&&c(f[0].index);Sd(b.id,ub[d],e);var h=Db(ub[d][Hb.Yd],b,[]);h&&h.length&&c(h[0].index)};c(a);}
var rh=!1,sh=function(a,b,c,d,e){if("gtm.js"==b){if(rh)return!1;rh=!0}Rd(a,b);var f=Sg(a,d,e);de(a,"event",1);de(a,"ecommerce",1);de(a,"gtm");var h={id:a,name:b,Yc:zg(c),xb:[],yh:[],Ge:function(){I("GTM",6)}};h.xb=Lb(h);var k=qh(h,f);"gtm.js"!==b&&"gtm.sync"!==b||ch(kd.s);if(!k)return k;for(var l=0;l<h.xb.length;l++)if(h.xb[l]){var m=ub[l];if(m&&!nd[String(m[Hb.ya])])return!0}return!1};function uh(a,b){}function vh(a,b){return wh()?uh(a,b):void 0}
function wh(){var a=!1;return a};var xh=function(){this.eventModel={};this.targetConfig={};this.containerConfig={};this.h={};this.globalConfig={};this.C=function(){};this.B=function(){};this.eventId=void 0},yh=function(a){var b=new xh;b.eventModel=a;return b},zh=function(a,b){a.targetConfig=b;return a},Ah=function(a,b){a.containerConfig=b;return a},Bh=function(a,b){a.h=b;return a},Ch=function(a,b){a.globalConfig=b;return a},Dh=function(a,b){a.C=b;return a},Eh=function(a,b){a.B=b;return a};
xh.prototype.getWithConfig=function(a){if(void 0!==this.eventModel[a])return this.eventModel[a];if(void 0!==this.targetConfig[a])return this.targetConfig[a];if(void 0!==this.containerConfig[a])return this.containerConfig[a];if(void 0!==this.h[a])return this.h[a];if(void 0!==this.globalConfig[a])return this.globalConfig[a]};
var Fh=function(a){function b(e){za(e,function(f){c[f]=null})}var c={};b(a.eventModel);b(a.targetConfig);b(a.containerConfig);b(a.globalConfig);var d=[];za(c,function(e){d.push(e)});return d};var Gh;if(3===kd.Ob.length)Gh="g";else{var Hh="G";Gh=Hh}
var Ih={"":"n",UA:"u",AW:"a",DC:"d",G:"e",GF:"f",HA:"h",GTM:Gh,OPT:"o"},Jh=function(a){var b=kd.s.split("-"),c=b[0].toUpperCase(),d=Ih[c]||"i",e=a&&"GTM"===c?b[1]:"OPT"===c?b[1]:"",f;if(3===kd.Ob.length){var h="w";f="2"+h}else f="";return f+d+kd.Ob+e};function Kh(){var a=!1;return a}
function Lh(a,b,c){function d(r){var u;ld.reported_gclid||(ld.reported_gclid={});u=ld.reported_gclid;var q=f+(r?"gcu":"gcs");if(!u[q]){u[q]=!0;var t=[],v=function(B,z){z&&t.push(B+"="+encodeURIComponent(z))},w="https://www.google.com";
v("gclid",Mh(b,f));v("gclsrc",h);v("gtm",Jh(!c));var A=w+"/pagead/landing?"+t.join("&");uc(A)}}var e=Jf(),f=e.gclid||"",h=e.gclsrc,k=e.dclid||"",l=!a&&(!f||h&&"aw.ds"!==h?!1:!0),m=Kh();if(l||m){var p=""+He();m?Sc(function(){d();Pc(C.o)||Rc(function(){return d(!0)})},[C.o]):d()}}
function Mh(a,b){return b}var Pi={},Qi=["G","GP"];Pi.Ye="";var Ri=Pi.Ye.split(",");function Si(){var a=ld;return a.gcq=a.gcq||new Ti}
var Ui=function(a,b,c){Si().register(a,b,c)},Vi=function(a,b,c,d){Si().push("event",[b,a],c,d)},Wi=function(a,b){Si().push("config",[a],b)},Xi={},Yi=function(a){return!0},Zi=function(){this.status=1;this.containerConfig={};this.targetConfig={};this.i={};this.m=null;this.h=!1},$i=function(a,b,c,d,e){this.type=a;this.m=b;this.ba=c||
"";this.h=d;this.i=e},Ti=function(){this.m={};this.i={};this.h=[]},aj=function(a,b){var c=bg(b);return a.m[c.containerId]=a.m[c.containerId]||new Zi},bj=function(a,b,c){if(b){var d=bg(b);if(d&&1===aj(a,b).status&&Yi(d.prefix)){aj(a,b).status=2;var e={};Pd&&(e.timeoutId=D.setTimeout(function(){I("GTM",38);Bd()},3E3));a.push("require",[e],d.containerId);Xi[d.containerId]=Fa();if(eg()){}else{var h="/gtag/js?id="+encodeURIComponent(d.containerId)+"&l=dataLayer&cx=c",k=("http:"!=D.location.protocol?"https:":"http:")+("//www.googletagmanager.com"+h),l=vh(c,h)||k;kc(l)}}}},cj=function(a,b,c,d){if(d.ba){var e=aj(a,d.ba),
f=e.m;if(f){var h=n(c),k=n(e.targetConfig[d.ba]),l=n(e.containerConfig),m=n(e.i),p=n(a.i),r=Zd("gtm.uniqueEventId"),u=bg(d.ba).prefix,q=Eh(Dh(Ch(Bh(Ah(zh(yh(h),k),l),m),p),function(){Td(r,u,"2");}),function(){Td(r,u,"3");});try{Td(r,u,"1");f(d.ba,b,d.m,q)}catch(t){
Td(r,u,"4");}}}};
Ti.prototype.register=function(a,b,c){if(3!==aj(this,a).status){aj(this,a).m=b;aj(this,a).status=3;c&&(aj(this,a).i=c);var d=bg(a),e=Xi[d.containerId];if(void 0!==e){var f=ld[d.containerId].bootstrap,h=d.prefix.toUpperCase();ld[d.containerId]._spx&&(h=h.toLowerCase());var k=Zd("gtm.uniqueEventId"),l=h,m=Fa()-f;if(Pd&&!Gd[k]){k!==Cd&&(Ad(),Cd=k);var p=l+"."+Math.floor(f-e)+"."+Math.floor(m);Ld=Ld?Ld+","+p:"&cl="+p}delete Xi[d.containerId]}this.flush()}};
Ti.prototype.push=function(a,b,c,d){var e=Math.floor(Fa()/1E3);bj(this,c,b[0][C.va]||this.i[C.va]);this.h.push(new $i(a,e,c,b,d));d||this.flush()};
Ti.prototype.flush=function(a){for(var b=this;this.h.length;){var c=this.h[0];if(c.i)c.i=!1,this.h.push(c);else switch(c.type){case "require":if(3!==aj(this,c.ba).status&&!a)return;Pd&&D.clearTimeout(c.h[0].timeoutId);break;case "set":za(c.h[0],function(l,m){n(Ma(l,m),b.i)});break;case "config":var d=c.h[0],e=!!d[C.hc];delete d[C.hc];var f=aj(this,c.ba),h=bg(c.ba),k=h.containerId===h.id;e||(k?f.containerConfig={}:f.targetConfig[c.ba]={});f.h&&e||cj(this,C.F,d,c);f.h=!0;delete d[C.wa];k?n(d,f.containerConfig):
n(d,f.targetConfig[c.ba]);break;case "event":cj(this,c.h[1],c.h[0],c)}this.h.shift()}};var dj=["GP","G"],ej="G".split(/,/);ej.push("GF");ej.push("HA");
ej.push("UA");ej.push("AW");var fj=!1;fj=!0;var gj=null,hj={},ij={},jj;function kj(a,b){var c={event:a};b&&(c.eventModel=n(b),b[C.Ac]&&(c.eventCallback=b[C.Ac]),b[C.Jb]&&(c.eventTimeout=b[C.Jb]));return c}
var pj={config:function(a){},event:function(a){var b=a[1];if(g(b)&&!(3<a.length)){var c;if(2<a.length){if(!Sa(a[2])&&void 0!=a[2])return;c=a[2]}var d=kj(b,c);return d}},js:function(a){if(2==a.length&&a[1].getTime)return{event:"gtm.js","gtm.start":a[1].getTime()}},policy:function(){},set:function(a){var b;2==a.length&&Sa(a[1])?b=n(a[1]):3==a.length&&g(a[1])&&(b={},
Sa(a[2])||ra(a[2])?b[a[1]]=n(a[2]):b[a[1]]=a[2]);if(b){b._clear=!0;return b}}};var qj={policy:!0};var rj=function(a,b){var c=a.hide;if(c&&void 0!==c[b]&&c.end){c[b]=!1;var d=!0,e;for(e in c)if(c.hasOwnProperty(e)&&!0===c[e]){d=!1;break}d&&(c.end(),c.end=null)}},tj=function(a){var b=sj(),c=b&&b.hide;c&&c.end&&(c[a]=!0)};var uj=!1,vj=[];function wj(){if(!uj){uj=!0;for(var a=0;a<vj.length;a++)G(vj[a])}}var xj=function(a){uj?G(a):vj.push(a)};var Pj=function(a){if(Oj(a))return a;this.h=a};Pj.prototype.Gg=function(){return this.h};var Oj=function(a){return!a||"object"!==Pa(a)||Sa(a)?!1:"getUntrustedUpdateValue"in a};Pj.prototype.getUntrustedUpdateValue=Pj.prototype.Gg;var Qj=[],Rj=!1,Sj=function(a){return D["dataLayer"].push(a)},Tj=function(a){var b=ld["dataLayer"],c=b?b.subscribers:1,d=0;return function(){++d===c&&a()}};
function Uj(a){var b=a._clear;za(a,function(f,h){"_clear"!==f&&(b&&ce(f,void 0),ce(f,h))});rd||(rd=a["gtm.start"]);var c=a.event,d=a["gtm.uniqueEventId"];if(!c)return!1;d||(d=xd(),a["gtm.uniqueEventId"]=d,ce("gtm.uniqueEventId",d));td=c;var e=Vj(a);td=null;switch(c){case "gtm.init":I("GTM",19),e&&I("GTM",20)}return e}
function Vj(a){var b=a.event,c=a["gtm.uniqueEventId"],d,e=ld.zones;d=e?e.checkState(kd.s,c):Cg;return d.active?sh(c,b,d.isWhitelisted,a.eventCallback,a.eventTimeout)?!0:!1:!1}
function Wj(){for(var a=!1;!Rj&&0<Qj.length;){Rj=!0;delete Wd.eventModel;Yd();var b=Qj.shift();if(null!=b){var c=Oj(b);if(c){var d=b;b=Oj(d)?d.getUntrustedUpdateValue():void 0;for(var e=["gtm.whitelist","gtm.blacklist","tagTypeBlacklist"],f=0;f<e.length;f++){var h=e[f],k=Zd(h,1);if(ra(k)||Sa(k))k=n(k);Xd[h]=k}}try{if(pa(b))try{b.call($d)}catch(v){}else if(ra(b)){var l=b;if(g(l[0])){var m=
l[0].split("."),p=m.pop(),r=l.slice(1),u=Zd(m.join("."),2);if(void 0!==u&&null!==u)try{u[p].apply(u,r)}catch(v){}}}else{var q=b;if(q&&("[object Arguments]"==Object.prototype.toString.call(q)||Object.prototype.hasOwnProperty.call(q,"callee"))){a:{if(b.length&&g(b[0])){var t=pj[b[0]];if(t&&(!c||!qj[b[0]])){b=t(b);break a}}b=void 0}if(!b){Rj=!1;continue}}a=Uj(b)||a}}finally{c&&Yd(!0)}}Rj=!1}
return!a}function Xj(){var a=Wj();try{rj(D["dataLayer"],kd.s)}catch(b){}return a}
var Zj=function(){var a=ic("dataLayer",[]),b=ic("google_tag_manager",{});b=b["dataLayer"]=b["dataLayer"]||{};Kg(function(){b.gtmDom||(b.gtmDom=!0,a.push({event:"gtm.dom"}))});xj(function(){b.gtmLoad||(b.gtmLoad=!0,a.push({event:"gtm.load"}))});b.subscribers=(b.subscribers||0)+1;var c=a.push;a.push=function(){var d;if(0<ld.SANDBOXED_JS_SEMAPHORE){d=[];for(var e=0;e<arguments.length;e++)d[e]=new Pj(arguments[e])}else d=[].slice.call(arguments,0);var f=c.apply(a,d);Qj.push.apply(Qj,d);if(300<
this.length)for(I("GTM",4);300<this.length;)this.shift();var h="boolean"!==typeof f||f;return Wj()&&h};Qj.push.apply(Qj,a.slice(0));Yj()&&G(Xj)},Yj=function(){var a=!0;return a};var ak={};ak.Kb=new String("undefined");
var bk=function(a){this.h=function(b){for(var c=[],d=0;d<a.length;d++)c.push(a[d]===ak.Kb?b:a[d]);return c.join("")}};bk.prototype.toString=function(){return this.h("undefined")};bk.prototype.valueOf=bk.prototype.toString;ak.Gf=bk;ak.Jc={};ak.pg=function(a){return new bk(a)};var ck={};ak.qh=function(a,b){var c=xd();ck[c]=[a,b];return c};ak.oe=function(a){var b=a?0:1;return function(c){var d=ck[c];if(d&&"function"===typeof d[b])d[b]();ck[c]=void 0}};ak.Pg=function(a){for(var b=!1,c=!1,d=2;d<a.length;d++)b=
b||8===a[d],c=c||16===a[d];return b&&c};ak.hh=function(a){if(a===ak.Kb)return a;var b=xd();ak.Jc[b]=a;return'google_tag_manager["'+kd.s+'"].macro('+b+")"};ak.Zg=function(a,b,c){a instanceof ak.Gf&&(a=a.h(ak.qh(b,c)),b=oa);return{Wc:a,C:b}};var dk=function(a,b,c){function d(f,h){var k=f[h];return k}var e={event:b,"gtm.element":a,"gtm.elementClasses":d(a,"className"),"gtm.elementId":a["for"]||qc(a,"id")||"","gtm.elementTarget":a.formTarget||d(a,"target")||""};c&&(e["gtm.triggers"]=c.join(","));e["gtm.elementUrl"]=(a.attributes&&a.attributes.formaction?a.formAction:"")||a.action||d(a,"href")||a.src||a.code||a.codebase||
"";return e},ek=function(a){ld.hasOwnProperty("autoEventsSettings")||(ld.autoEventsSettings={});var b=ld.autoEventsSettings;b.hasOwnProperty(a)||(b[a]={});return b[a]},fk=function(a,b,c){ek(a)[b]=c},gk=function(a,b,c,d){var e=ek(a),f=Ga(e,b,d);e[b]=c(f)},hk=function(a,b,c){var d=ek(a);return Ga(d,b,c)};var ik=["input","select","textarea"],jk=["button","hidden","image","reset","submit"],kk=function(a){var b=a.tagName.toLowerCase();return!va(ik,function(c){return c===b})||"input"===b&&va(jk,function(c){return c===a.type.toLowerCase()})?!1:!0},lk=function(a){return a.form?a.form.tagName?a.form:F.getElementById(a.form):tc(a,["form"],100)},mk=function(a,b,c){if(!a.elements)return 0;for(var d=b.getAttribute(c),e=0,f=1;e<a.elements.length;e++){var h=a.elements[e];if(kk(h)){if(h.getAttribute(c)===d)return f;
f++}}return 0};var nk=!!D.MutationObserver,ok=void 0,pk=function(a){if(!ok){var b=function(){var c=F.body;if(c)if(nk)(new MutationObserver(function(){for(var e=0;e<ok.length;e++)G(ok[e])})).observe(c,{childList:!0,subtree:!0});else{var d=!1;oc(c,"DOMNodeInserted",function(){d||(d=!0,G(function(){d=!1;for(var e=0;e<ok.length;e++)G(ok[e])}))})}};ok=[];F.body?b():G(b)}ok.push(a)};var Kk=D.clearTimeout,Lk=D.setTimeout,P=function(a,b,c){if(eg()){b&&G(b)}else return kc(a,b,c)},Mk=function(){return D.location.href},Nk=function(a){return ne(pe(a),"fragment")},Ok=function(a){return oe(pe(a))},R=function(a,b){return Zd(a,b||2)},Pk=function(a,b,c){var d;b?(a.eventCallback=b,c&&(a.eventTimeout=c),d=Sj(a)):d=Sj(a);return d},Qk=function(a,b){D[a]=b},S=function(a,b,c){b&&(void 0===D[a]||c&&!D[a])&&(D[a]=
b);return D[a]},Rk=function(a,b,c){return ve(a,b,void 0===c?!0:!!c)},Sk=function(a,b,c){return 0===Ee(a,b,c)},Tk=function(a,b){if(eg()){b&&G(b)}else mc(a,b)},Uk=function(a){return!!hk(a,"init",!1)},Vk=function(a){fk(a,"init",!0)},Wk=function(a,b){var c=(void 0===b?0:b)?"www.googletagmanager.com/gtag/js":qd;c+="?id="+encodeURIComponent(a)+"&l=dataLayer";P(K("https://","http://",c))},Xk=function(a,b){var c=a[b];return c};
var Yk=ak.Zg;function ul(a,b){a=String(a);b=String(b);var c=a.length-b.length;return 0<=c&&a.indexOf(b,c)==c}var vl=new xa;function wl(a,b){function c(h){var k=pe(h),l=ne(k,"protocol"),m=ne(k,"host",!0),p=ne(k,"port"),r=ne(k,"path").toLowerCase().replace(/\/$/,"");if(void 0===l||"http"==l&&"80"==p||"https"==l&&"443"==p)l="web",p="default";return[l,m,p,r]}for(var d=c(String(a)),e=c(String(b)),f=0;f<d.length;f++)if(d[f]!==e[f])return!1;return!0}
function xl(a){return yl(a)?1:0}
function yl(a){var b=a.arg0,c=a.arg1;if(a.any_of&&ra(c)){for(var d=0;d<c.length;d++)if(xl({"function":a["function"],arg0:b,arg1:c[d]}))return!0;return!1}switch(a["function"]){case "_cn":return 0<=String(b).indexOf(String(c));case "_css":var e;a:{if(b){var f=["matches","webkitMatchesSelector","mozMatchesSelector","msMatchesSelector","oMatchesSelector"];try{for(var h=0;h<f.length;h++)if(b[f[h]]){e=b[f[h]](c);break a}}catch(u){}}e=!1}return e;case "_ew":return ul(b,c);case "_eq":return String(b)==String(c);
case "_ge":return Number(b)>=Number(c);case "_gt":return Number(b)>Number(c);case "_lc":var k;k=String(b).split(",");return 0<=ta(k,String(c));case "_le":return Number(b)<=Number(c);case "_lt":return Number(b)<Number(c);case "_re":var l;var m=a.ignore_case?"i":void 0;try{var p=String(c)+m,r=vl.get(p);r||(r=new RegExp(c,m),vl.set(p,r));l=r.test(b)}catch(u){l=!1}return l;case "_sw":return 0==String(b).indexOf(String(c));case "_um":return wl(b,c)}return!1};var zl=function(a,b){var c=function(){};c.prototype=a.prototype;var d=new c;a.apply(d,Array.prototype.slice.call(arguments,1));return d};var Al={},Bl=encodeURI,W=encodeURIComponent,Cl=nc;var Dl=function(a,b){if(!a)return!1;var c=ne(pe(a),"host");if(!c)return!1;for(var d=0;b&&d<b.length;d++){var e=b[d]&&b[d].toLowerCase();if(e){var f=c.length-e.length;0<f&&"."!=e.charAt(0)&&(f--,e="."+e);if(0<=f&&c.indexOf(e,f)==f)return!0}}return!1};
var El=function(a,b,c){for(var d={},e=!1,f=0;a&&f<a.length;f++)a[f]&&a[f].hasOwnProperty(b)&&a[f].hasOwnProperty(c)&&(d[a[f][b]]=a[f][c],e=!0);return e?d:null};Al.Qg=function(){var a=!1;return a};var Wm=function(){var a=D.gaGlobal=D.gaGlobal||{};a.hid=a.hid||wa();return a.hid};var gn=window,hn=document,jn=function(a){var b=gn._gaUserPrefs;if(b&&b.ioo&&b.ioo()||a&&!0===gn["ga-disable-"+a])return!0;try{var c=gn.external;if(c&&c._gaUserPrefs&&"oo"==c._gaUserPrefs)return!0}catch(f){}for(var d=re("AMP_TOKEN",String(hn.cookie),!0),e=0;e<d.length;e++)if("$OPT_OUT"==d[e])return!0;return hn.getElementById("__gaOptOutExtension")?!0:!1};
function mn(a,b){delete b.eventModel[C.wa];if(a!==C.F){var c=b.getWithConfig(C.bc);if(ra(c)){I("GTM",26);for(var d={},e=0;e<c.length;e++){var f=c[e],h=b.getWithConfig(f);void 0!==h&&(d[f]=h)}b.eventModel=d}}on(b.eventModel)}var on=function(a){za(a,function(c){"_"===c.charAt(0)&&delete a[c]});var b=a[C.ka]||{};za(b,function(c){"_"===c.charAt(0)&&delete b[c]})};var rn=function(a,b,c){Vi(b,c,a)},sn=function(a,b,c){Vi(b,c,a,!0)},un=function(a,b){};
function tn(a,b){}var X={a:{}};


X.a.e=["google"],function(){(function(a){X.__e=a;X.__e.b="e";X.__e.g=!0;X.__e.priorityOverride=0})(function(a){return String(ee(a.vtp_gtmEventId,"event"))})}();
X.a.f=["google"],function(){(function(a){X.__f=a;X.__f.b="f";X.__f.g=!0;X.__f.priorityOverride=0})(function(a){var b=R("gtm.referrer",1)||F.referrer;return b?a.vtp_component&&"URL"!=a.vtp_component?ne(pe(String(b)),a.vtp_component,a.vtp_stripWww,a.vtp_defaultPages,a.vtp_queryKey):Ok(String(b)):String(b)})}();
X.a.r=["google"],function(){(function(a){X.__r=a;X.__r.b="r";X.__r.g=!0;X.__r.priorityOverride=0})(function(a){return wa(a.vtp_min,a.vtp_max)})}();
X.a.u=["google"],function(){var a=function(b){return{toString:function(){return b}}};(function(b){X.__u=b;X.__u.b="u";X.__u.g=!0;X.__u.priorityOverride=0})(function(b){var c;b.vtp_customUrlSource?c=b.vtp_customUrlSource:c=R("gtm.url",1);c=c||Mk();var d=b[a("vtp_component")];if(!d||"URL"==d)return Ok(String(c));var e=pe(String(c)),f;if("QUERY"===d)a:{var h=b[a("vtp_multiQueryKeys").toString()],k=b[a("vtp_queryKey").toString()]||"",l=b[a("vtp_ignoreEmptyQueryParam").toString()],m;h?ra(k)?m=k:m=String(k).replace(/\s+/g,
"").split(","):m=[String(k)];for(var p=0;p<m.length;p++){var r=ne(e,"QUERY",void 0,void 0,m[p]);if(void 0!=r&&(!l||""!==r)){f=r;break a}}f=void 0}else f=ne(e,d,"HOST"==d?b[a("vtp_stripWww")]:void 0,"PATH"==d?b[a("vtp_defaultPages")]:void 0,void 0);return f})}();
X.a.v=["google"],function(){(function(a){X.__v=a;X.__v.b="v";X.__v.g=!0;X.__v.priorityOverride=0})(function(a){var b=a.vtp_name;if(!b||!b.replace)return!1;var c=R(b.replace(/\\\./g,"."),a.vtp_dataLayerVersion||1);return void 0!==c?c:a.vtp_defaultValue})}();
X.a.ua=["google"],function(){var a,b={},c=function(e){Sc(function(){d(e)},[C.J,C.o])},d=function(e){var f={},h={},k={},l={},m={};if(e.vtp_gaSettings){var p=e.vtp_gaSettings;n(El(p.vtp_fieldsToSet,"fieldName","value"),h);n(El(p.vtp_contentGroup,"index","group"),k);n(El(p.vtp_dimension,"index","dimension"),l);n(El(p.vtp_metric,"index","metric"),m);e.vtp_gaSettings=null;p.vtp_fieldsToSet=void 0;p.vtp_contentGroup=void 0;p.vtp_dimension=void 0;p.vtp_metric=void 0;var r=n(p);e=n(e,r)}n(El(e.vtp_fieldsToSet,
"fieldName","value"),h);n(El(e.vtp_contentGroup,"index","group"),k);n(El(e.vtp_dimension,"index","dimension"),l);n(El(e.vtp_metric,"index","metric"),m);var u=$g(e.vtp_functionName);if(pa(u)){var q="",t="";e.vtp_setTrackerName&&"string"==typeof e.vtp_trackerName?""!==e.vtp_trackerName&&(t=e.vtp_trackerName,q=t+"."):(t="gtm"+xd(),
q=t+".");var v={name:!0,clientId:!0,sampleRate:!0,siteSpeedSampleRate:!0,alwaysSendReferrer:!0,allowAnchor:!0,allowLinker:!0,cookieName:!0,cookieDomain:!0,cookieExpires:!0,cookiePath:!0,cookieUpdate:!0,cookieFlags:!0,legacyCookieDomain:!0,legacyHistoryImport:!0,storage:!0,useAmpClientId:!0,storeGac:!0},w={allowAnchor:!0,allowLinker:!0,alwaysSendReferrer:!0,anonymizeIp:!0,cookieUpdate:!0,exFatal:!0,forceSSL:!0,javaEnabled:!0,legacyHistoryImport:!0,nonInteraction:!0,useAmpClientId:!0,useBeacon:!0,storeGac:!0,
allowAdFeatures:!0,allowAdPersonalizationSignals:!0},y=function(O){var Q=[].slice.call(arguments,0);Q[0]=q+Q[0];u.apply(window,Q)},x=function(O,Q){return void 0===Q?Q:O(Q)},A=function(O,Q){if(Q)for(var Qa in Q)Q.hasOwnProperty(Qa)&&y("set",O+Qa,Q[Qa])},B=function(){},
z=function(O,Q,Qa){var Tb=0;if(O)for(var Ea in O)if(O.hasOwnProperty(Ea)&&(Qa&&v[Ea]||!Qa&&void 0===v[Ea])){var cb=w[Ea]?Ba(O[Ea]):O[Ea];"anonymizeIp"!=Ea||cb||(cb=void 0);Q[Ea]=cb;Tb++}return Tb},E={name:t};z(h,E,!0);u("create",e.vtp_trackingId||f.trackingId,E);y("set","&gtm",Jh(!0));e.vtp_enableRecaptcha&&y("require","recaptcha","recaptcha.js");(function(O,Q){void 0!==e[Q]&&y("set",O,e[Q])})("nonInteraction","vtp_nonInteraction");A("contentGroup",k);A("dimension",l);A("metric",m);var H={};z(h,H,!1)&&y("set",H);var M;
e.vtp_enableLinkId&&y("require","linkid","linkid.js");y("set","hitCallback",function(){var O=h&&h.hitCallback;pa(O)&&O();e.vtp_gtmOnSuccess()});if("TRACK_EVENT"==e.vtp_trackType){e.vtp_enableEcommerce&&(y("require","ec","ec.js"),B());var N={hitType:"event",eventCategory:String(e.vtp_eventCategory||f.category),eventAction:String(e.vtp_eventAction||f.action),eventLabel:x(String,e.vtp_eventLabel||f.label),eventValue:x(Aa,e.vtp_eventValue||
f.value)};z(M,N,!1);y("send",N);}else if("TRACK_SOCIAL"==e.vtp_trackType){}else if("TRACK_TRANSACTION"==e.vtp_trackType){}else if("TRACK_TIMING"==
e.vtp_trackType){}else if("DECORATE_LINK"==e.vtp_trackType){}else if("DECORATE_FORM"==e.vtp_trackType){}else if("TRACK_DATA"==e.vtp_trackType){}else{e.vtp_enableEcommerce&&(y("require","ec","ec.js"),B());if(e.vtp_doubleClick||"DISPLAY_FEATURES"==e.vtp_advertisingFeaturesType){var V=
"_dc_gtm_"+String(e.vtp_trackingId).replace(/[^A-Za-z0-9-]/g,"");y("require","displayfeatures",void 0,{cookieName:V})}if("DISPLAY_FEATURES_WITH_REMARKETING_LISTS"==e.vtp_advertisingFeaturesType){var ma="_dc_gtm_"+String(e.vtp_trackingId).replace(/[^A-Za-z0-9-]/g,"");y("require","adfeatures",{cookieName:ma})}M?y("send","pageview",M):y("send","pageview");}if(!a){var ua=e.vtp_useDebugVersion?"u/analytics_debug.js":"analytics.js";e.vtp_useInternalVersion&&!e.vtp_useDebugVersion&&(ua="internal/"+ua);a=!0;var La=vh(h._x_19,"/analytics.js"),ka=K("https:","http:","//www.google-analytics.com/"+ua,h&&h.forceSSL);P("analytics.js"===ua&&La?La:ka,function(){var O=Yg();O&&O.loaded||e.vtp_gtmOnFailure();},e.vtp_gtmOnFailure)}}else G(e.vtp_gtmOnFailure)};
X.__ua=c;X.__ua.b="ua";X.__ua.g=!0;X.__ua.priorityOverride=0}();






X.a.aev=["google"],function(){function a(q,t){var v=ee(q,"gtm");if(v)return v[t]}function b(q,t,v,w){w||(w="element");var y=q+"."+t,x;if(p.hasOwnProperty(y))x=p[y];else{var A=a(q,w);if(A&&(x=v(A),p[y]=x,r.push(y),35<r.length)){var B=r.shift();delete p[B]}}return x}function c(q,t,v){var w=a(q,u[t]);return void 0!==w?w:v}function d(q,t){if(!q)return!1;var v=e(Mk());ra(t)||(t=String(t||"").replace(/\s+/g,"").split(","));for(var w=[v],y=0;y<t.length;y++)if(t[y]instanceof RegExp){if(t[y].test(q))return!1}else{var x=
t[y];if(0!=x.length){if(0<=e(q).indexOf(x))return!1;w.push(e(x))}}return!Dl(q,w)}function e(q){m.test(q)||(q="http://"+q);return ne(pe(q),"HOST",!0)}function f(q,t,v){switch(q){case "SUBMIT_TEXT":return b(t,"FORM."+q,h,"formSubmitElement")||v;case "LENGTH":var w=b(t,"FORM."+q,k);return void 0===w?v:w;case "INTERACTED_FIELD_ID":return l(t,"id",v);case "INTERACTED_FIELD_NAME":return l(t,"name",v);case "INTERACTED_FIELD_TYPE":return l(t,"type",v);case "INTERACTED_FIELD_POSITION":var y=a(t,"interactedFormFieldPosition");
return void 0===y?v:y;case "INTERACT_SEQUENCE_NUMBER":var x=a(t,"interactSequenceNumber");return void 0===x?v:x;default:return v}}function h(q){switch(q.tagName.toLowerCase()){case "input":return qc(q,"value");case "button":return rc(q);default:return null}}function k(q){if("form"===q.tagName.toLowerCase()&&q.elements){for(var t=0,v=0;v<q.elements.length;v++)kk(q.elements[v])&&t++;return t}}function l(q,t,v){var w=a(q,"interactedFormField");return w&&qc(w,t)||v}var m=/^https?:\/\//i,p={},r=[],u={ATTRIBUTE:"elementAttribute",
CLASSES:"elementClasses",ELEMENT:"element",ID:"elementId",HISTORY_CHANGE_SOURCE:"historyChangeSource",HISTORY_NEW_STATE:"newHistoryState",HISTORY_NEW_URL_FRAGMENT:"newUrlFragment",HISTORY_OLD_STATE:"oldHistoryState",HISTORY_OLD_URL_FRAGMENT:"oldUrlFragment",TARGET:"elementTarget"};(function(q){X.__aev=q;X.__aev.b="aev";X.__aev.g=!0;X.__aev.priorityOverride=0})(function(q){var t=q.vtp_gtmEventId,v=q.vtp_defaultValue,w=q.vtp_varType;switch(w){case "TAG_NAME":var y=a(t,"element");return y&&y.tagName||
v;case "TEXT":return b(t,w,rc)||v;case "URL":var x;a:{var A=String(a(t,"elementUrl")||v||""),B=pe(A),z=String(q.vtp_component||"URL");switch(z){case "URL":x=A;break a;case "IS_OUTBOUND":x=d(A,q.vtp_affiliatedDomains);break a;default:x=ne(B,z,q.vtp_stripWww,q.vtp_defaultPages,q.vtp_queryKey)}}return x;case "ATTRIBUTE":var E;if(void 0===q.vtp_attribute)E=c(t,w,v);else{var H=q.vtp_attribute,M=a(t,"element");E=M&&qc(M,H)||v||""}return E;case "MD":var N=q.vtp_mdValue,Y=b(t,"MD",wk);return N&&Y?zk(Y,N)||
v:Y||v;case "FORM":return f(String(q.vtp_component||"SUBMIT_TEXT"),t,v);default:return c(t,w,v)}})}();







X.a.paused=[],function(){(function(a){X.__paused=a;X.__paused.b="paused";X.__paused.g=!0;X.__paused.priorityOverride=0})(function(a){G(a.vtp_gtmOnFailure)})}();
X.a.html=["customScripts"],function(){function a(d,e,f,h){return function(){try{if(0<e.length){var k=e.shift(),l=a(d,e,f,h);if("SCRIPT"==String(k.nodeName).toUpperCase()&&"text/gtmscript"==k.type){var m=F.createElement("script");m.async=!1;m.type="text/javascript";m.id=k.id;m.text=k.text||k.textContent||k.innerHTML||"";k.charset&&(m.charset=k.charset);var p=k.getAttribute("data-gtmsrc");p&&(m.src=p,jc(m,l));d.insertBefore(m,null);p||l()}else if(k.innerHTML&&0<=k.innerHTML.toLowerCase().indexOf("<script")){for(var r=
[];k.firstChild;)r.push(k.removeChild(k.firstChild));d.insertBefore(k,null);a(k,r,l,h)()}else d.insertBefore(k,null),l()}else f()}catch(u){G(h)}}}var b=function(d,e,f){Kg(function(){var h,k=ld;k.postscribe||(k.postscribe=fc);h=k.postscribe;var l={done:e},m=F.createElement("div");m.style.display="none";m.style.visibility="hidden";F.body.appendChild(m);try{h(m,d,l)}catch(p){G(f)}})};var c=function(d){if(F.body){var e=
d.vtp_gtmOnFailure,f=Yk(d.vtp_html,d.vtp_gtmOnSuccess,e),h=f.Wc,k=f.C;if(d.vtp_useIframe){}else d.vtp_supportDocumentWrite?b(h,k,e):a(F.body,sc(h),k,e)()}else Lk(function(){c(d)},
200)};X.__html=c;X.__html.b="html";X.__html.g=!0;X.__html.priorityOverride=0}();




X.a.img=["customPixels"],function(){(function(a){X.__img=a;X.__img.b="img";X.__img.g=!0;X.__img.priorityOverride=0})(function(a){var b=sc('<a href="'+a.vtp_url+'"></a>')[0].href,c=a.vtp_cacheBusterQueryParam;if(a.vtp_useCacheBuster){c||(c="gtmcb");var d=b.charAt(b.length-1),e=0<=b.indexOf("?")?"?"==d||"&"==d?"":"&":"?";b+=e+c+"="+a.vtp_randomNumber}Cl(b,a.vtp_gtmOnSuccess,a.vtp_gtmOnFailure)})}();




var vn={};vn.macro=function(a){if(ak.Jc.hasOwnProperty(a))return ak.Jc[a]},vn.onHtmlSuccess=ak.oe(!0),vn.onHtmlFailure=ak.oe(!1);vn.dataLayer=$d;vn.callback=function(a){vd.hasOwnProperty(a)&&pa(vd[a])&&vd[a]();delete vd[a]};function wn(){ld[kd.s]=vn;Ia(wd,X.a);yb=yb||ak;zb=Bg}
function xn(){se.gtm_3pds=!0;ld=D.google_tag_manager=D.google_tag_manager||{};if(ld[kd.s]){var a=ld.zones;a&&a.unregisterChild(kd.s);}else{for(var b=data.resource||{},c=b.macros||[],d=0;d<c.length;d++)rb.push(c[d]);for(var e=b.tags||[],f=0;f<e.length;f++)ub.push(e[f]);for(var h=b.predicates||[],k=0;k<h.length;k++)tb.push(h[k]);for(var l=b.rules||[],m=0;m<l.length;m++){for(var p=l[m],r={},u=0;u<p.length;u++)r[p[u][0]]=Array.prototype.slice.call(p[u],1);sb.push(r)}wb=X;xb=xl;wn();Zj();Fg=!1;Gg=0;if("interactive"==F.readyState&&!F.createEventObject||"complete"==F.readyState)Ig();
else{oc(F,"DOMContentLoaded",Ig);oc(F,"readystatechange",Ig);if(F.createEventObject&&F.documentElement.doScroll){var q=!0;try{q=!D.frameElement}catch(y){}q&&Jg()}oc(D,"load",Ig)}uj=!1;"complete"===F.readyState?wj():oc(D,"load",wj);a:{if(!Pd)break a;D.setInterval(Qd,
864E5);}sd=(new Date).getTime();}}
(function(a){
a()})(xn);

})()
